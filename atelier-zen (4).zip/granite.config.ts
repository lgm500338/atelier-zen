import { defineConfig } from '@apps-in-toss/web-framework/config';

export default defineConfig({
  appName: 'atelier-zen',
  brand: {
    primaryColor: '#D97706',
  },
  navigationBar: {
    withBackButton: true,
    withTitle: true,
    theme: 'light',
  },
  webView: {
    bounces: false,
    pullToRefreshEnabled: false,
    overScrollMode: 'never',
  },
  webBundleDir: 'dist',
  permissions: [],
});
