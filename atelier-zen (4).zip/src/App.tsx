import React, { useState, useEffect } from 'react';
import { AlertCircle } from 'lucide-react';
import { Header } from './components/Header';
import { TimelapseViewer } from './components/TimelapseViewer';
import { ColoringStudio } from './components/ColoringStudio';
import { GalleryView } from './components/GalleryView';
import { MySketchbook } from './components/MySketchbook';
import { PhotoToSketchModal } from './components/PhotoToSketchModal';
import { MASTER_ARTWORKS } from './data/artworks';
import { Artwork, SavedPainting } from './types/artwork';
import { generateProceduralArtwork } from './utils/proceduralArt';
import { sound } from './utils/audio';
import { initSafeArea } from './utils/tossBridge';

export default function App() {
  const [artworks, setArtworks] = useState<Artwork[]>(() => {
    try {
      const saved = localStorage.getItem('atelier_zen_artworks');
      if (saved) {
        const parsed = JSON.parse(saved);
        return [...parsed, ...MASTER_ARTWORKS];
      }
    } catch {
      // Fallback
    }
    return MASTER_ARTWORKS;
  });

  const [savedPaintings, setSavedPaintings] = useState<SavedPainting[]>(() => {
    try {
      const saved = localStorage.getItem('atelier_zen_saved_paintings');
      if (saved) return JSON.parse(saved);
    } catch {
      // Fallback
    }
    return [];
  });

  const [currentArtwork, setCurrentArtwork] = useState<Artwork>(MASTER_ARTWORKS[0]);
  const [currentTab, setCurrentTab] = useState<'timelapse' | 'coloring' | 'gallery'>('timelapse');
  const [isPhotoModalOpen, setIsPhotoModalOpen] = useState<boolean>(false);
  const [viewingSketchbook, setViewingSketchbook] = useState<boolean>(false);
  const [storageErrorMessage, setStorageErrorMessage] = useState<string | null>(null);

  // Initialize Toss and Web Safe Area Insets on mount
  useEffect(() => {
    const cleanup = initSafeArea();
    return () => {
      cleanup();
    };
  }, []);

  // Sync custom artworks safely
  useEffect(() => {
    try {
      const customOnly = artworks.filter((a) => a.isCustom);
      localStorage.setItem('atelier_zen_artworks', JSON.stringify(customOnly));
    } catch (e) {
      console.warn('Storage quota reached for custom artworks:', e);
      setStorageErrorMessage('저장 공간이 가득 찼어요. 스케치북에서 오래된 작품을 정리해 주세요.');
    }
  }, [artworks]);

  // Navigate to artwork
  const handleSelectArtwork = (artwork: Artwork, mode: 'timelapse' | 'coloring') => {
    setCurrentArtwork(artwork);
    setViewingSketchbook(false);
    setCurrentTab(mode);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Generate limitless algorithmic artwork
  const handleGenerateProcedural = () => {
    const themes: Array<'urban' | 'botanical' | 'oil' | 'pop'> = ['urban', 'botanical', 'oil', 'pop'];
    const randomTheme = themes[Math.floor(Math.random() * themes.length)];
    const newArt = generateProceduralArtwork(randomTheme, 'medium');

    setArtworks((prev) => [newArt, ...prev]);
    setCurrentArtwork(newArt);
    setCurrentTab('timelapse');
    setViewingSketchbook(false);
    sound.playZenChime(659.25, 2.5, 0.08); // E5 chime
  };

  // Convert uploaded photo
  const handlePhotoArtworkReady = (newArt: Artwork, mode: 'timelapse' | 'coloring') => {
    setArtworks((prev) => [newArt, ...prev]);
    setCurrentArtwork(newArt);
    setCurrentTab(mode);
    setViewingSketchbook(false);
  };

  // Save coloring to gallery safely with user feedback
  const handleSaveToGallery = (painting: SavedPainting): boolean => {
    const nextList = [painting, ...savedPaintings];
    try {
      localStorage.setItem('atelier_zen_saved_paintings', JSON.stringify(nextList));
      setSavedPaintings(nextList);
      setStorageErrorMessage(null);
      return true;
    } catch (e) {
      console.warn('Storage quota reached for saved paintings:', e);
      setStorageErrorMessage('저장 공간이 가득 찼어요. 스케치북에서 오래된 작품을 정리해 주세요.');
      return false;
    }
  };

  const handleDeleteSavedPainting = (id: string) => {
    const nextList = savedPaintings.filter((p) => p.id !== id);
    setSavedPaintings(nextList);
    try {
      localStorage.setItem('atelier_zen_saved_paintings', JSON.stringify(nextList));
    } catch (e) {
      console.warn('Failed to update storage after delete:', e);
    }
  };

  // Next / Prev artwork in playlist
  const currentIndex = artworks.findIndex((a) => a.id === currentArtwork.id);
  const hasNext = currentIndex < artworks.length - 1 || artworks.length > 1;
  const hasPrev = currentIndex > 0;

  const handleNextArtwork = () => {
    if (artworks.length === 0) return;
    const nextIdx = (currentIndex + 1) % artworks.length;
    setCurrentArtwork(artworks[nextIdx]);
  };

  const handlePrevArtwork = () => {
    if (artworks.length === 0) return;
    const prevIdx = (currentIndex - 1 + artworks.length) % artworks.length;
    setCurrentArtwork(artworks[prevIdx]);
  };

  return (
    <div className="min-h-screen bg-[#F7F5F0] text-stone-900 flex flex-col font-sans selection:bg-amber-200">
      {/* Top Header with Safe Area Inset */}
      <Header
        currentTab={viewingSketchbook ? 'gallery' : currentTab}
        setCurrentTab={(tab) => {
          if (tab === 'gallery') {
            setViewingSketchbook(true);
          } else {
            setViewingSketchbook(false);
            setCurrentTab(tab);
          }
        }}
        onOpenPhotoModal={() => setIsPhotoModalOpen(true)}
        onGenerateProcedural={handleGenerateProcedural}
      />

      {/* Main Workspace */}
      <main className="flex-1 py-6">
        {viewingSketchbook ? (
          <MySketchbook
            savedList={savedPaintings}
            artworks={artworks}
            onOpenArtwork={handleSelectArtwork}
            onDeleteSaved={handleDeleteSavedPainting}
          />
        ) : currentTab === 'timelapse' ? (
          <div className="space-y-10">
            {/* Active Drawing Timelapse */}
            <TimelapseViewer
              artwork={currentArtwork}
              onColorNow={(art) => handleSelectArtwork(art, 'coloring')}
              onNextArtwork={handleNextArtwork}
              onPrevArtwork={handlePrevArtwork}
              hasNext={hasNext}
              hasPrev={hasPrev}
            />

            {/* Below Player: Curated Catalog Grid */}
            <div className="pt-6 border-t border-stone-200/80">
              <GalleryView
                artworks={artworks}
                onSelectArtwork={handleSelectArtwork}
                onOpenPhotoModal={() => setIsPhotoModalOpen(true)}
                onGenerateProcedural={handleGenerateProcedural}
              />
            </div>
          </div>
        ) : (
          <ColoringStudio
            artwork={currentArtwork}
            onSaveToGallery={handleSaveToGallery}
            onBackToTimelapse={() => setCurrentTab('timelapse')}
          />
        )}
      </main>

      {/* Photo to Sketch Modal */}
      <PhotoToSketchModal
        isOpen={isPhotoModalOpen}
        onClose={() => setIsPhotoModalOpen(false)}
        onArtworkReady={handlePhotoArtworkReady}
      />

      {/* Storage Full Warning Floating Banner with Safe Area Inset */}
      {storageErrorMessage && (
        <div
          style={{ bottom: 'calc(var(--sab, 0px) + 1.5rem)' }}
          className="fixed left-1/2 -translate-x-1/2 z-50 max-w-md w-[92%] bg-stone-900/95 backdrop-blur-md text-white px-4 py-3 rounded-2xl shadow-2xl flex items-center justify-between gap-3 text-xs md:text-sm border border-rose-500/50 animate-in fade-in slide-in-from-bottom-2 duration-200"
        >
          <div className="flex items-center gap-2 text-rose-300">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span className="text-stone-100">{storageErrorMessage}</span>
          </div>
          <button
            onClick={() => setStorageErrorMessage(null)}
            className="text-stone-400 hover:text-white px-2 py-1 text-sm font-bold cursor-pointer"
            aria-label="알림 닫기"
          >
            ✕
          </button>
        </div>
      )}

      {/* Museum Editorial Footer with Safe Area Bottom */}
      <footer
        style={{ paddingBottom: 'calc(var(--sab, 0px) + 2rem)' }}
        className="mt-auto border-t border-stone-200/80 bg-[#FAF8F5] pt-8 px-4 md:px-8 text-xs text-stone-500"
      >
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-serif text-base font-semibold text-stone-800">Atelier Zen</span>
            <span>·</span>
            <span>어반스케치 멍때리기 & 힐링 컬러링 스튜디오</span>
          </div>

          <div className="text-center sm:text-right text-stone-400">
            100% 로컬 연산 · 외부 유료 API 불필요 · 무제한 힐링 아틀리에
          </div>
        </div>
      </footer>
    </div>
  );
}
