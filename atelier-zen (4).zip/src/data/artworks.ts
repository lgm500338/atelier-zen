import { Artwork } from '../types/artwork';

export const MASTER_ARTWORKS: Artwork[] = [
  // 1. Urban Sketch (Inspired directly by user's uploaded reels)
  {
    id: 'urban-forest-cottage',
    title: '숲속 붉은 지붕 오두막과 뭉게구름',
    category: 'urban',
    categoryName: '어반스케치 & 수채화',
    difficulty: 'medium',
    difficultyName: '중급 (몰입 힐링)',
    volume: 'Vol. 1',
    description: '사각사각 펜으로 스케치한 숲속 작은 집 위로 맑은 연두빛 물감이 번지고, 붉은 지붕과 파란 하늘 뭉게구름이 완성되는 따뜻한 전원 풍경입니다.',
    durationSeconds: 42,
    width: 700,
    height: 850,
    palette: ['#4A7C59', '#8CB369', '#D4E09B', '#C94A29', '#E09F3E', '#5B85AA', '#F4F1DE', '#333333'],
    layers: [
      {
        id: 'layer-pen-sketch',
        name: '01. 사각사각 펜 스케치 (윤곽선 & 해칭)',
        style: 'pen',
        paths: [
          // Ground contour
          { type: 'stroke', color: '#2B2724', lineWidth: 1.8, d: 'M 60 700 Q 220 685 360 700 T 640 690' },
          { type: 'stroke', color: '#3A3530', lineWidth: 1.2, d: 'M 100 710 Q 240 705 400 715 T 620 705' },
          // Ground grass hatching
          { type: 'stroke', color: '#3A3530', lineWidth: 1.0, d: 'M 90 705 L 105 690 M 110 705 L 125 690 M 130 705 L 145 690 M 150 705 L 165 690' },
          { type: 'stroke', color: '#3A3530', lineWidth: 1.0, d: 'M 480 710 L 495 695 M 500 710 L 515 695 M 520 710 L 535 695 M 540 710 L 555 695' },
          // Cottage walls & base
          { type: 'stroke', color: '#2B2724', lineWidth: 2.2, d: 'M 250 690 L 250 560 L 410 560 L 410 690 Z' },
          { type: 'stroke', color: '#2B2724', lineWidth: 2.0, d: 'M 410 560 L 460 540 L 460 670 L 410 690' },
          // Roof
          { type: 'stroke', color: '#2B2724', lineWidth: 2.4, d: 'M 235 565 L 330 490 L 425 565 Z' },
          { type: 'stroke', color: '#2B2724', lineWidth: 2.2, d: 'M 330 490 L 465 470 L 475 540 L 410 560' },
          // Chimney
          { type: 'stroke', color: '#2B2724', lineWidth: 1.8, d: 'M 380 500 L 380 470 L 405 465 L 405 510' },
          { type: 'stroke', color: '#3A3530', lineWidth: 1.0, d: 'M 382 480 L 403 476 M 382 490 L 403 486' },
          // Windows & Door
          { type: 'stroke', color: '#2B2724', lineWidth: 1.8, d: 'M 270 580 H 305 V 620 H 270 Z' },
          { type: 'stroke', color: '#3A3530', lineWidth: 1.2, d: 'M 287 580 V 620 M 270 600 H 305' },
          { type: 'stroke', color: '#2B2724', lineWidth: 1.8, d: 'M 345 580 H 380 V 620 H 345 Z' },
          { type: 'stroke', color: '#3A3530', lineWidth: 1.2, d: 'M 362 580 V 620 M 345 600 H 380' },
          { type: 'stroke', color: '#2B2724', lineWidth: 1.8, d: 'M 430 575 H 450 V 630 H 430 Z' },
          // Shading hatching under eaves and walls
          { type: 'stroke', color: '#3A3530', lineWidth: 1.0, d: 'M 252 566 L 270 575 M 265 566 L 283 575 M 278 566 L 296 575 M 291 566 L 309 575' },
          { type: 'stroke', color: '#3A3530', lineWidth: 0.9, d: 'M 415 565 L 455 550 M 415 580 L 455 565 M 415 595 L 455 580 M 415 610 L 455 595' },
          // Tree trunks & main branches
          { type: 'stroke', color: '#26211C', lineWidth: 2.2, d: 'M 520 685 Q 540 520 500 380 Q 480 300 460 250' },
          { type: 'stroke', color: '#26211C', lineWidth: 1.8, d: 'M 505 500 Q 550 440 600 390' },
          { type: 'stroke', color: '#26211C', lineWidth: 1.5, d: 'M 530 420 Q 580 340 610 270' },
          { type: 'stroke', color: '#26211C', lineWidth: 1.8, d: 'M 200 680 Q 180 540 150 440' },
          { type: 'stroke', color: '#26211C', lineWidth: 1.5, d: 'M 175 510 Q 120 460 80 430' },
          // Foliage contour squiggles (Urban sketch style)
          { type: 'stroke', color: '#2D3025', lineWidth: 1.4, d: 'M 460 240 C 490 200 550 210 580 250 C 620 230 660 270 650 320 C 670 360 640 410 610 420 C 630 460 600 510 570 530' },
          { type: 'stroke', color: '#2D3025', lineWidth: 1.4, d: 'M 380 280 C 410 230 450 250 460 290 C 490 300 480 360 450 380' },
          { type: 'stroke', color: '#2D3025', lineWidth: 1.4, d: 'M 60 450 C 50 380 110 330 160 340 C 180 290 240 280 270 330 C 310 320 340 370 320 420 C 330 460 280 500 240 520 C 210 550 140 550 100 510 Z' }
        ]
      },
      {
        id: 'layer-watercolor-wash',
        name: '02. 초벌 맑은 수채화 번짐 (Base Wash)',
        style: 'watercolor',
        paths: [
          // Sky wash
          { type: 'wash', color: 'rgba(91, 133, 170, 0.45)', lineWidth: 35, d: 'M 40 180 Q 200 120 380 140 T 660 110 L 660 300 Q 400 340 40 320 Z' },
          { type: 'wash', color: 'rgba(125, 172, 210, 0.35)', lineWidth: 30, d: 'M 60 140 Q 280 90 480 110 T 650 90' },
          // Ground pale lime/golden wash
          { type: 'wash', color: 'rgba(212, 224, 155, 0.55)', lineWidth: 40, d: 'M 40 730 Q 300 680 660 700 L 660 790 L 40 790 Z' },
          // Cottage wall soft ochre wash
          { type: 'wash', color: 'rgba(235, 230, 215, 0.7)', lineWidth: 20, d: 'M 252 565 H 455 V 685 H 252 Z' },
          // Foliage sunny yellow-green wash
          { type: 'wash', color: 'rgba(180, 215, 100, 0.55)', lineWidth: 45, d: 'M 440 230 C 520 180 640 220 630 330 C 650 420 580 530 500 520 C 440 460 410 320 440 230 Z' },
          { type: 'wash', color: 'rgba(195, 220, 110, 0.55)', lineWidth: 40, d: 'M 70 430 C 70 320 220 280 290 320 C 330 380 310 490 220 520 C 130 540 70 480 70 430 Z' }
        ]
      },
      {
        id: 'layer-foliage-texture',
        name: '03. 잎사귀 명암 터치 & 붉은 지붕 채색',
        style: 'watercolor',
        paths: [
          // Roof warm vermilion watercolor
          { type: 'wash', color: 'rgba(201, 74, 41, 0.75)', lineWidth: 24, d: 'M 240 563 L 330 493 L 420 563 Z' },
          { type: 'wash', color: 'rgba(180, 50, 30, 0.85)', lineWidth: 20, d: 'M 330 493 L 465 473 L 473 538 L 415 560 Z' },
          { type: 'wash', color: 'rgba(150, 35, 20, 0.6)', lineWidth: 14, d: 'M 380 502 L 403 468 L 403 508 Z' },
          // Middle green foliage dapples
          { type: 'wash', color: 'rgba(74, 124, 89, 0.65)', lineWidth: 22, d: 'M 470 260 Q 530 240 570 280 T 600 350' },
          { type: 'wash', color: 'rgba(74, 124, 89, 0.65)', lineWidth: 25, d: 'M 520 340 Q 580 320 610 380 T 570 450' },
          { type: 'wash', color: 'rgba(50, 100, 65, 0.75)', lineWidth: 20, d: 'M 480 430 Q 520 400 550 460 T 500 520' },
          { type: 'wash', color: 'rgba(74, 124, 89, 0.65)', lineWidth: 24, d: 'M 100 420 Q 150 360 210 380 T 270 420' },
          { type: 'wash', color: 'rgba(50, 100, 65, 0.75)', lineWidth: 22, d: 'M 140 460 Q 180 420 220 470 T 200 530' },
          // Deep moss shadow foliage under trees
          { type: 'wash', color: 'rgba(35, 75, 45, 0.8)', lineWidth: 16, d: 'M 490 480 Q 520 460 550 500 T 510 540' },
          { type: 'wash', color: 'rgba(35, 75, 45, 0.8)', lineWidth: 16, d: 'M 210 490 Q 240 480 260 520' },
          // Tree trunk watercolor stain
          { type: 'wash', color: 'rgba(70, 50, 35, 0.75)', lineWidth: 10, d: 'M 522 670 Q 535 520 503 390' },
          { type: 'wash', color: 'rgba(70, 50, 35, 0.75)', lineWidth: 8, d: 'M 198 670 Q 180 540 152 450' }
        ]
      },
      {
        id: 'layer-cloud-highlights',
        name: '04. 여름 뭉게구름 & 디테일 하이라이트',
        style: 'highlight',
        paths: [
          // Fluffy white cumulus cloud borders
          { type: 'wash', color: 'rgba(255, 255, 255, 0.85)', lineWidth: 25, d: 'M 120 180 C 130 140 190 130 220 160 C 250 140 300 150 320 190 C 350 180 390 200 380 240' },
          { type: 'wash', color: 'rgba(255, 255, 255, 0.9)', lineWidth: 30, d: 'M 180 170 Q 250 130 330 170' },
          // Window reflection & contrast
          { type: 'wash', color: 'rgba(40, 55, 70, 0.8)', lineWidth: 12, d: 'M 275 585 H 300 V 615 H 275 Z' },
          { type: 'wash', color: 'rgba(40, 55, 70, 0.8)', lineWidth: 12, d: 'M 350 585 H 375 V 615 H 350 Z' },
          { type: 'stroke', color: 'rgba(255, 255, 255, 0.75)', lineWidth: 1.5, d: 'M 278 588 L 295 605 M 353 588 L 370 605' },
          // Highlight touches on leaves
          { type: 'stipple', color: '#D4E09B', lineWidth: 5, d: 'M 490 260 M 540 240 M 580 290 M 460 320 M 180 340 M 230 320 M 280 360' }
        ]
      }
    ]
  },

  // 2. Urban Sketch: Montmartre Cafe
  {
    id: 'urban-montmartre-cafe',
    title: '파리 몽마르트르 골목 카페와 자전거',
    category: 'urban',
    categoryName: '어반스케치 & 수채화',
    difficulty: 'hard',
    difficultyName: '고급 (디테일 마스터)',
    volume: 'Vol. 1',
    description: '유럽 오래된 석조 건물 1층에 자리 잡은 빈티지 카페 차양과 테라스 테이블, 기대어 놓인 자전거의 감성적인 스케치입니다.',
    durationSeconds: 50,
    width: 700,
    height: 850,
    palette: ['#2F3E46', '#52796F', '#84A98C', '#CAD2C5', '#DDA15E', '#BC6C25', '#9A031E', '#354F52'],
    layers: [
      {
        id: 'layer-cafe-pen',
        name: '01. 카페 건축 & 자전거 펜 드로잉',
        style: 'pen',
        paths: [
          // Building facade & roofline
          { type: 'stroke', color: '#2B2625', lineWidth: 2.2, d: 'M 80 120 L 620 120 M 80 120 L 80 720 M 620 120 L 620 720' },
          { type: 'stroke', color: '#3A3532', lineWidth: 1.4, d: 'M 120 180 H 260 V 300 H 120 Z' },
          { type: 'stroke', color: '#3A3532', lineWidth: 1.4, d: 'M 440 180 H 580 V 300 H 440 Z' },
          // Window shutters
          { type: 'stroke', color: '#3A3532', lineWidth: 1.2, d: 'M 100 180 H 120 V 300 H 100 Z M 260 180 H 280 V 300 H 260 Z' },
          { type: 'stroke', color: '#3A3532', lineWidth: 1.2, d: 'M 420 180 H 440 V 300 H 420 Z M 580 180 H 600 V 300 H 580 Z' },
          // Awning (Cafe shade)
          { type: 'stroke', color: '#2B2625', lineWidth: 2.4, d: 'M 100 400 L 140 470 L 560 470 L 600 400 Z' },
          { type: 'stroke', color: '#3A3532', lineWidth: 1.2, d: 'M 200 410 L 220 470 M 290 410 L 305 470 M 390 410 L 395 470 M 480 410 L 475 470' },
          // Cafe sign
          { type: 'stroke', color: '#2B2625', lineWidth: 1.8, d: 'M 240 350 H 460 V 390 H 240 Z' },
          // Cafe door & large windows
          { type: 'stroke', color: '#2B2625', lineWidth: 2.0, d: 'M 140 480 H 300 V 680 H 140 Z' },
          { type: 'stroke', color: '#2B2625', lineWidth: 2.0, d: 'M 340 480 H 560 V 680 H 340 Z' },
          // Terrace table & chairs
          { type: 'stroke', color: '#2B2625', lineWidth: 1.6, d: 'M 180 620 Q 220 610 260 620 L 220 690' },
          // Vintage bicycle
          { type: 'stroke', color: '#2B2625', lineWidth: 1.8, d: 'M 440 640 A 30 30 0 1 0 440 641' },
          { type: 'stroke', color: '#2B2625', lineWidth: 1.8, d: 'M 540 640 A 30 30 0 1 0 540 641' },
          { type: 'stroke', color: '#2B2625', lineWidth: 2.0, d: 'M 440 640 L 480 590 L 520 640 L 470 640 Z' },
          { type: 'stroke', color: '#2B2625', lineWidth: 1.8, d: 'M 480 590 L 470 560 M 520 640 L 515 570 M 500 565 H 530' },
          // Cobblestone ground
          { type: 'stroke', color: '#4A4540', lineWidth: 1.0, d: 'M 100 700 Q 350 690 600 700' },
          { type: 'stroke', color: '#4A4540', lineWidth: 0.9, d: 'M 120 710 Q 150 715 180 710 M 250 715 Q 280 720 310 715 M 400 710 Q 430 715 460 710' }
        ]
      },
      {
        id: 'layer-cafe-wash',
        name: '02. 차양 스트라이프 & 벽돌 수채화',
        style: 'watercolor',
        paths: [
          // Burgundy & ivory awning stripes
          { type: 'wash', color: 'rgba(154, 3, 30, 0.75)', lineWidth: 28, d: 'M 140 410 L 160 470 M 230 410 L 245 470 M 320 410 L 330 470 M 410 410 L 415 470 M 500 410 L 495 470' },
          { type: 'wash', color: 'rgba(240, 235, 220, 0.8)', lineWidth: 25, d: 'M 185 410 L 205 470 M 275 410 L 285 470 M 365 410 L 370 470 M 455 410 L 455 470 M 545 410 L 535 470' },
          // Stone building warm wash
          { type: 'wash', color: 'rgba(221, 161, 94, 0.35)', lineWidth: 40, d: 'M 90 130 H 610 V 390 H 90 Z' },
          // Window reflection cyan wash
          { type: 'wash', color: 'rgba(132, 169, 140, 0.45)', lineWidth: 30, d: 'M 150 490 H 290 V 670 H 150 Z' },
          { type: 'wash', color: 'rgba(132, 169, 140, 0.45)', lineWidth: 30, d: 'M 350 490 H 550 V 670 H 350 Z' }
        ]
      },
      {
        id: 'layer-cafe-details',
        name: '03. 골목길 명암 & 따뜻한 조명 불빛',
        style: 'highlight',
        paths: [
          // Warm amber cafe interior glow
          { type: 'wash', color: 'rgba(238, 155, 0, 0.65)', lineWidth: 24, d: 'M 200 520 Q 230 500 260 540' },
          { type: 'wash', color: 'rgba(238, 155, 0, 0.65)', lineWidth: 24, d: 'M 400 520 Q 450 500 480 540' },
          // Bicycle forest green paint
          { type: 'wash', color: 'rgba(47, 62, 70, 0.8)', lineWidth: 6, d: 'M 440 640 L 480 590 L 520 640' },
          // Flower pots outside cafe
          { type: 'wash', color: 'rgba(200, 60, 40, 0.8)', lineWidth: 14, d: 'M 110 670 H 135 V 690 H 110 Z' },
          { type: 'wash', color: 'rgba(82, 121, 111, 0.85)', lineWidth: 18, d: 'M 105 660 Q 120 640 140 660' }
        ]
      }
    ]
  },

  // 3. Classic Oil: Van Gogh Starry Night
  {
    id: 'oil-starry-hills',
    title: '별이 빛나는 밤의 사이프러스 언덕',
    category: 'oil',
    categoryName: '클래식 유화 (임파스토)',
    difficulty: 'hard',
    difficultyName: '고급 (디테일 마스터)',
    volume: 'Vol. 1',
    description: '고흐 특유의 소용돌이치는 밤하늘과 황금빛 별빛, 묵직하고 굽이치는 사이프러스 나무의 두터운 붓결을 감상하는 명화 유화입니다.',
    durationSeconds: 48,
    width: 750,
    height: 600,
    palette: ['#0B1B3D', '#1B3B6F', '#21295C', '#E2AFDE', '#F5EE9E', '#F49E4C', '#283618', '#606C38'],
    layers: [
      {
        id: 'layer-oil-sky-swirl',
        name: '01. 소용돌이 밤하늘 붓터치 (Deep Ultramarine)',
        style: 'oil',
        paths: [
          // Base dark night wash
          { type: 'wash', color: '#0B1B3D', lineWidth: 80, d: 'M 0 0 H 750 V 600 H 0 Z' },
          // Swirling blue brushstrokes
          { type: 'stroke', color: '#1B3B6F', lineWidth: 8.0, d: 'M 100 200 C 200 120 300 240 400 160 C 500 80 620 180 720 130' },
          { type: 'stroke', color: '#2C5282', lineWidth: 7.0, d: 'M 80 230 C 180 150 280 270 380 190 C 480 110 600 210 700 160' },
          { type: 'stroke', color: '#4299E1', lineWidth: 6.0, d: 'M 120 180 C 220 100 320 220 420 140 C 520 60 640 160 740 110' },
          { type: 'stroke', color: '#63B3ED', lineWidth: 4.5, d: 'M 250 180 C 280 150 320 150 350 180 C 370 200 360 230 330 230 C 300 230 290 200 310 180' }
        ]
      },
      {
        id: 'layer-oil-stars-moon',
        name: '02. 황금빛 달과 은하수 별빛 텍스처',
        style: 'oil',
        paths: [
          // Golden Crescent Moon
          { type: 'wash', color: 'rgba(245, 238, 158, 0.4)', lineWidth: 45, d: 'M 640 100 A 35 35 0 1 1 640 101' },
          { type: 'stroke', color: '#F49E4C', lineWidth: 6.0, d: 'M 620 80 Q 660 80 660 120 Q 640 140 620 120 Q 640 100 620 80' },
          { type: 'stroke', color: '#FEEBC8', lineWidth: 4.0, d: 'M 625 85 Q 655 85 655 115' },
          // Radiant halo circles around stars
          { type: 'stroke', color: 'rgba(245, 238, 158, 0.8)', lineWidth: 3.5, d: 'M 180 90 A 25 25 0 1 1 180 91' },
          { type: 'stroke', color: 'rgba(244, 158, 76, 0.8)', lineWidth: 3.0, d: 'M 180 90 A 15 15 0 1 1 180 91' },
          { type: 'stipple', color: '#FFFFFF', lineWidth: 8.0, d: 'M 180 90 M 480 80 M 640 100 M 350 70 M 560 180 M 240 250' }
        ]
      },
      {
        id: 'layer-oil-cypress-hills',
        name: '03. 사이프러스 나무 & 구불거리는 언덕',
        style: 'oil',
        paths: [
          // Rolling hills
          { type: 'stroke', color: '#1A365D', lineWidth: 14.0, d: 'M 0 420 Q 250 360 480 430 T 750 400' },
          { type: 'stroke', color: '#2D3748', lineWidth: 12.0, d: 'M 0 460 Q 300 400 550 480 T 750 450' },
          { type: 'wash', color: '#283618', lineWidth: 40, d: 'M 0 500 Q 350 450 750 510 L 750 600 L 0 600 Z' },
          // Majestic dark Cypress tree towering in foreground
          { type: 'stroke', color: '#132014', lineWidth: 18.0, d: 'M 120 600 Q 90 400 130 220 Q 140 150 135 120' },
          { type: 'stroke', color: '#283618', lineWidth: 10.0, d: 'M 100 580 Q 75 420 115 250' },
          { type: 'stroke', color: '#3A5A40', lineWidth: 6.0, d: 'M 130 550 Q 150 380 125 260' },
          { type: 'stroke', color: '#588157', lineWidth: 4.0, d: 'M 115 500 Q 95 380 120 280' }
        ]
      }
    ]
  },

  // 4. Classic Oil: Monet Water Lilies
  {
    id: 'oil-monet-lilies',
    title: '모네의 지베르니 수련 정원',
    category: 'oil',
    categoryName: '클래식 유화 (임파스토)',
    difficulty: 'medium',
    difficultyName: '중급 (몰입 힐링)',
    volume: 'Vol. 1',
    description: '물결에 비치는 버드나무 그림자와 맑은 수면 위로 피어난 연분홍 수련꽃, 인상주의 특유의 찰나의 빛을 담은 유화입니다.',
    durationSeconds: 38,
    width: 750,
    height: 550,
    palette: ['#2A4736', '#416D54', '#7BA082', '#9BB7A6', '#C7D8C6', '#D68C9E', '#EBBAB9', '#F9E4B7'],
    layers: [
      {
        id: 'layer-water-surface',
        name: '01. 에메랄드 수면과 수초 그림자',
        style: 'oil',
        paths: [
          // Base pond reflection
          { type: 'wash', color: '#2A4736', lineWidth: 60, d: 'M 0 0 H 750 V 550 H 0 Z' },
          { type: 'stroke', color: '#416D54', lineWidth: 12, d: 'M 50 100 Q 250 80 450 110 T 700 90' },
          { type: 'stroke', color: '#5C8D70', lineWidth: 10, d: 'M 20 220 Q 300 200 520 230 T 730 210' },
          { type: 'stroke', color: '#7BA082', lineWidth: 8, d: 'M 80 340 Q 350 320 580 350 T 710 330' },
          { type: 'stroke', color: '#9BB7A6', lineWidth: 6, d: 'M 30 440 Q 280 420 540 450 T 740 430' }
        ]
      },
      {
        id: 'layer-lily-pads',
        name: '02. 수면 위 둥근 수련 잎사귀 군락',
        style: 'oil',
        paths: [
          // Water lily pads (floating ellipses)
          { type: 'wash', color: '#1B3828', lineWidth: 16, d: 'M 120 380 C 180 370 200 410 140 420 C 100 425 80 395 120 380 Z' },
          { type: 'wash', color: '#315C42', lineWidth: 14, d: 'M 320 280 C 400 270 420 310 350 320 C 300 325 280 295 320 280 Z' },
          { type: 'wash', color: '#2D523B', lineWidth: 18, d: 'M 500 360 C 600 350 630 400 540 410 C 480 415 460 380 500 360 Z' },
          { type: 'wash', color: '#3A684C', lineWidth: 12, d: 'M 220 180 C 280 175 290 200 240 205 C 200 210 190 190 220 180 Z' }
        ]
      },
      {
        id: 'layer-water-blossoms',
        name: '03. 피어나는 연분홍 수련꽃 & 햇살 반사',
        style: 'highlight',
        paths: [
          // Pink lily blossoms
          { type: 'stroke', color: '#EBBAB9', lineWidth: 5, d: 'M 145 375 L 140 360 M 145 375 L 150 355 M 145 375 L 160 365' },
          { type: 'stipple', color: '#D68C9E', lineWidth: 12, d: 'M 148 370 M 355 275 M 545 355 M 245 175' },
          { type: 'stipple', color: '#F9E4B7', lineWidth: 6, d: 'M 148 368 M 355 273 M 545 353' },
          // Glistening light reflections on water
          { type: 'stroke', color: 'rgba(255, 255, 255, 0.65)', lineWidth: 2.5, d: 'M 300 240 H 340 M 450 320 H 510 M 180 420 H 230' }
        ]
      }
    ]
  },

  // 5. Botanical: Monstera & Dewdrop
  {
    id: 'botanical-monstera',
    title: '몬스테라와 아침 이슬 잎사귀',
    category: 'botanical',
    categoryName: '보태니컬 & 네이처',
    difficulty: 'easy',
    difficultyName: '초급 (편안한 힐링)',
    volume: 'Vol. 1',
    description: '크고 시원하게 갈라진 몬스테라 잎맥과 맑은 아침 이슬방울이 싱그럽게 번져가는 편안한 보태니컬 수채화입니다.',
    durationSeconds: 28,
    width: 650,
    height: 750,
    palette: ['#2D4739', '#4E6E58', '#739E82', '#A3C4BC', '#E0ECE4', '#F4F9F4'],
    layers: [
      {
        id: 'layer-leaf-pen',
        name: '01. 싱그러운 몬스테라 윤곽선',
        style: 'pen',
        paths: [
          // Central leaf stem
          { type: 'stroke', color: '#243B2E', lineWidth: 2.4, d: 'M 325 700 Q 320 400 325 150' },
          // Monstera leaf outline with splits
          { type: 'stroke', color: '#243B2E', lineWidth: 2.0, d: 'M 325 150 C 380 180 440 240 450 320 C 420 325 380 320 370 340 C 440 370 470 430 460 490 C 410 480 370 490 360 520 C 420 560 420 620 370 650 C 350 660 335 680 325 700' },
          { type: 'stroke', color: '#243B2E', lineWidth: 2.0, d: 'M 325 150 C 270 180 210 240 200 320 C 230 325 270 320 280 340 C 210 370 180 430 190 490 C 240 480 280 490 290 520 C 230 560 230 620 280 650 C 300 660 315 680 325 700' },
          // Internal splits (windows/holes)
          { type: 'stroke', color: '#243B2E', lineWidth: 1.8, d: 'M 350 360 C 365 340 380 350 375 380 C 370 400 355 390 350 360 Z' },
          { type: 'stroke', color: '#243B2E', lineWidth: 1.8, d: 'M 290 420 C 275 400 260 410 265 440 C 270 460 285 450 290 420 Z' }
        ]
      },
      {
        id: 'layer-leaf-gradient',
        name: '02. 청량한 숲속 수채화 그러데이션',
        style: 'watercolor',
        paths: [
          // Base sage wash
          { type: 'wash', color: 'rgba(115, 158, 130, 0.5)', lineWidth: 40, d: 'M 325 160 Q 420 300 340 660 Q 230 300 325 160 Z' },
          // Deep emerald shading along main vein
          { type: 'wash', color: 'rgba(45, 71, 57, 0.7)', lineWidth: 22, d: 'M 325 180 Q 320 400 325 670' },
          // Lighter soft mint accents on leaf tips
          { type: 'wash', color: 'rgba(163, 196, 188, 0.6)', lineWidth: 30, d: 'M 440 310 Q 460 410 430 480' },
          { type: 'wash', color: 'rgba(163, 196, 188, 0.6)', lineWidth: 30, d: 'M 210 310 Q 190 410 220 480' }
        ]
      },
      {
        id: 'layer-leaf-dew',
        name: '03. 맑은 투명 이슬방울 하이라이트',
        style: 'highlight',
        paths: [
          // Dewdrop shadows
          { type: 'stroke', color: 'rgba(30, 50, 40, 0.6)', lineWidth: 1.8, d: 'M 360 270 A 10 10 0 1 1 360 271' },
          { type: 'stroke', color: 'rgba(30, 50, 40, 0.6)', lineWidth: 1.8, d: 'M 260 380 A 12 12 0 1 1 260 381' },
          // Dewdrop white light gleam
          { type: 'stipple', color: '#FFFFFF', lineWidth: 4, d: 'M 358 268 M 258 378 M 340 500' }
        ]
      }
    ]
  },

  // 6. Pop Art: Modern Espresso & Graphic Still Life
  {
    id: 'pop-espresso-time',
    title: '모던 팝아트 커피와 휴식',
    category: 'pop',
    categoryName: '팝아트 & 모던 그래픽',
    difficulty: 'easy',
    difficultyName: '초급 (편안한 힐링)',
    volume: 'Vol. 1',
    description: '굵고 경쾌한 블랙 라인과 비비드한 컬러 블록으로 완성하는 미드센추리 감성의 모던 팝아트 일러스트입니다.',
    durationSeconds: 24,
    width: 650,
    height: 650,
    palette: ['#E63946', '#F1FAEE', '#A8DADC', '#457B9D', '#1D3557', '#FFB703', '#FB8500'],
    layers: [
      {
        id: 'layer-pop-lines',
        name: '01. 또렷하고 굵은 팝아트 라인워크',
        style: 'pen',
        paths: [
          // Background graphic sun circle
          { type: 'stroke', color: '#1D3557', lineWidth: 3.5, d: 'M 325 150 A 120 120 0 1 1 325 151' },
          // Table horizontal line
          { type: 'stroke', color: '#1D3557', lineWidth: 4.0, d: 'M 60 480 H 590' },
          // Coffee cup & saucer
          { type: 'stroke', color: '#1D3557', lineWidth: 3.8, d: 'M 200 480 H 450 V 495 H 200 Z' },
          { type: 'stroke', color: '#1D3557', lineWidth: 3.8, d: 'M 230 360 H 420 L 400 475 H 250 Z' },
          // Cup handle
          { type: 'stroke', color: '#1D3557', lineWidth: 3.5, d: 'M 415 385 C 465 385 465 440 405 440' },
          // Coffee steam graphic waves
          { type: 'stroke', color: '#1D3557', lineWidth: 3.0, d: 'M 290 320 Q 275 280 295 240 T 285 200' },
          { type: 'stroke', color: '#1D3557', lineWidth: 3.0, d: 'M 360 320 Q 345 280 365 240 T 355 200' }
        ]
      },
      {
        id: 'layer-pop-color-blocks',
        name: '02. 비비드 컬러 블록 채우기',
        style: 'watercolor',
        paths: [
          // Golden sun background fill
          { type: 'wash', color: 'rgba(255, 183, 3, 0.9)', lineWidth: 50, d: 'M 325 210 A 80 80 0 1 1 325 211' },
          // Vermilion red coffee cup
          { type: 'wash', color: 'rgba(230, 57, 70, 0.95)', lineWidth: 35, d: 'M 245 375 H 405 L 390 465 H 260 Z' },
          // Navy table shadow
          { type: 'wash', color: 'rgba(69, 123, 157, 0.4)', lineWidth: 40, d: 'M 60 495 H 590 V 600 H 60 Z' }
        ]
      },
      {
        id: 'layer-pop-highlights',
        name: '03. 팝아트 광택 & 하이라이트',
        style: 'highlight',
        paths: [
          // White gleam on red cup
          { type: 'stroke', color: '#FFFFFF', lineWidth: 4.0, d: 'M 260 385 L 255 450' },
          // Deep espresso surface
          { type: 'wash', color: '#2B1704', lineWidth: 15, d: 'M 245 370 H 405' }
        ]
      }
    ]
  }
];
