import React, { useEffect, useRef, useState, useCallback } from 'react';
import { Play, Pause, RotateCcw, FastForward, Palette, Volume2, Sparkles, CheckCircle2, ChevronRight, ChevronLeft } from 'lucide-react';
import { Artwork, DrawPath, DrawingLayer } from '../types/artwork';
import { sound } from '../utils/audio';

interface TimelapseViewerProps {
  artwork: Artwork;
  onColorNow: (artwork: Artwork) => void;
  onNextArtwork?: () => void;
  onPrevArtwork?: () => void;
  hasNext?: boolean;
  hasPrev?: boolean;
}

export const TimelapseViewer: React.FC<TimelapseViewerProps> = ({
  artwork,
  onColorNow,
  onNextArtwork,
  onPrevArtwork,
  hasNext = true,
  hasPrev = true
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [progress, setProgress] = useState<number>(0); // 0 to 1
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1.0);
  const [autoNext, setAutoNext] = useState<boolean>(true);
  const [activeLayerIndex, setActiveLayerIndex] = useState<number>(0);

  // Flatten all paths with their parent layer for sequential animation
  const flattenedItems = useRef<Array<{ path: DrawPath; layerIndex: number; layer: DrawingLayer }>>([]);

  useEffect(() => {
    const items: Array<{ path: DrawPath; layerIndex: number; layer: DrawingLayer }> = [];
    artwork.layers.forEach((layer, layerIdx) => {
      layer.paths.forEach((path) => {
        items.push({ path, layerIndex: layerIdx, layer });
      });
    });
    flattenedItems.current = items;
    setProgress(0);
    setActiveLayerIndex(0);
    setIsPlaying(true);
  }, [artwork]);

  // Main canvas drawing function
  const renderFrame = useCallback((prog: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // High DPI crispness
    const w = artwork.width;
    const h = artwork.height;

    // Reset canvas with soft watercolor cold-press tone
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = '#FAF7F2';
    ctx.fillRect(0, 0, w, h);

    // Subtle paper grain dots
    ctx.fillStyle = 'rgba(160, 140, 120, 0.035)';
    for (let py = 0; py < h; py += 12) {
      for (let px = 0; px < w; px += 12) {
        ctx.fillRect(px, py, 1, 1);
      }
    }

    const items = flattenedItems.current;
    const totalCount = items.length;
    const itemsToDraw = Math.floor(prog * totalCount);

    let lastActiveLayer = 0;

    for (let i = 0; i < itemsToDraw; i++) {
      const item = items[i];
      lastActiveLayer = item.layerIndex;
      drawSinglePath(ctx, item.path, item.layer.style);
    }

    setActiveLayerIndex(lastActiveLayer);
  }, [artwork]);

  // Animation loop
  useEffect(() => {
    let animId: number;
    let lastTime = performance.now();

    const loop = (time: number) => {
      if (isPlaying) {
        const delta = (time - lastTime) / 1000;
        lastTime = time;

        const baseDuration = artwork.durationSeconds || 35;
        const advance = (delta * playbackSpeed) / baseDuration;

        setProgress((prev) => {
          const next = prev + advance;
          if (next >= 1.0) {
            setIsPlaying(false);
            sound.playZenChime(523.25, 3.5, 0.08); // C5 completion chord

            if (autoNext && onNextArtwork) {
              setTimeout(() => {
                onNextArtwork();
              }, 2400);
            }
            return 1.0;
          }

          // Sound ASMR feedback: trigger subtle scratch/wash periodically
          if (Math.random() < 0.18 * playbackSpeed) {
            const currentItemIdx = Math.floor(next * flattenedItems.current.length);
            const currentItem = flattenedItems.current[currentItemIdx];
            if (currentItem?.layer.style === 'pen') {
              sound.playPencilScratch(0.06);
            } else if (currentItem?.layer.style === 'watercolor') {
              sound.playWaterBrush(0.07);
            }
          }

          return next;
        });
      } else {
        lastTime = time;
      }

      animId = requestAnimationFrame(loop);
    };

    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, [isPlaying, playbackSpeed, artwork, autoNext, onNextArtwork]);

  // Render on progress change
  useEffect(() => {
    renderFrame(progress);
  }, [progress, renderFrame]);

  const handlePlayPause = () => {
    if (progress >= 1.0) {
      setProgress(0);
      setIsPlaying(true);
    } else {
      setIsPlaying(!isPlaying);
    }
  };

  const handleScrubberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setProgress(val);
    if (isPlaying) setIsPlaying(false);
  };

  const handleInstantFinish = () => {
    setProgress(1.0);
    setIsPlaying(false);
    sound.playZenChime(523.25, 2.5, 0.08);
  };

  const currentLayerName = artwork.layers[activeLayerIndex]?.name || '드로잉 진행 중';

  return (
    <div className="w-full flex flex-col items-center">
      {/* Artwork Header & Metadata */}
      <div className="w-full max-w-4xl px-4 mb-4 flex flex-col sm:flex-row sm:items-baseline justify-between gap-2 border-b border-stone-200/80 pb-3">
        <div>
          <div className="flex items-center gap-2 text-xs text-stone-500 mb-1">
            <span>{artwork.categoryName}</span>
            <span aria-hidden="true">·</span>
            <span>{artwork.difficultyName}</span>
            <span aria-hidden="true">·</span>
            <span>{artwork.volume}</span>
          </div>
          <h2 className="font-serif text-2xl sm:text-3xl font-medium text-stone-900 tracking-tight">
            {artwork.title}
          </h2>
        </div>

        {/* Quick Prev / Next navigation */}
        <div className="flex items-center gap-2">
          {hasPrev && (
            <button
              onClick={onPrevArtwork}
              className="p-1.5 text-stone-600 hover:text-stone-900 hover:bg-stone-200/50 rounded-lg transition-colors"
              title="이전 작품"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
          )}
          {hasNext && (
            <button
              onClick={onNextArtwork}
              className="p-1.5 text-stone-600 hover:text-stone-900 hover:bg-stone-200/50 rounded-lg transition-colors"
              title="다음 작품"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          )}
        </div>
      </div>

      {/* Main Canvas Presentation Screen */}
      <div className="relative w-full max-w-3xl flex justify-center items-center px-4">
        <div className="relative rounded-2xl overflow-hidden canvas-paper-shadow border border-stone-300/60 bg-[#FAF7F2]">
          <canvas
            ref={canvasRef}
            width={artwork.width}
            height={artwork.height}
            className="w-full max-h-[68vh] object-contain block select-none"
            style={{ aspectRatio: `${artwork.width} / ${artwork.height}` }}
          />

          {/* Current Drawing Stage Indicator Badge */}
          <div className="absolute top-3 left-3 px-3 py-1.5 bg-stone-900/75 backdrop-blur-md rounded-lg text-white text-xs font-medium flex items-center gap-2 shadow-xs transition-all">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="tracking-tight">{currentLayerName}</span>
          </div>

          {/* Completed Overlay Banner */}
          {progress >= 1.0 && (
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 px-5 py-2.5 bg-stone-900/85 backdrop-blur-md rounded-xl text-white text-xs sm:text-sm flex items-center gap-3 shadow-lg animate-in fade-in zoom-in-95 duration-200">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>완성되었습니다. 이제 직접 칠해보실래요?</span>
              <button
                onClick={() => onColorNow(artwork)}
                className="px-3 py-1 bg-amber-500 hover:bg-amber-400 text-stone-950 font-semibold rounded-lg transition-colors whitespace-nowrap shadow-xs"
              >
                직접 칠하기
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Control Utility Ribbon */}
      <div className="w-full max-w-3xl px-4 mt-5 space-y-3">
        {/* Scrubber Progress Bar */}
        <div className="flex items-center gap-3">
          <span className="text-xs font-mono tabular-nums text-stone-500 w-10 text-right">
            {Math.round(progress * 100)}%
          </span>
          <div className="relative flex-1 group py-2">
            <input
              type="range"
              min="0"
              max="1"
              step="0.005"
              value={progress}
              onChange={handleScrubberChange}
              className="w-full h-1.5 bg-stone-200 rounded-lg appearance-none cursor-pointer accent-stone-800 focus:outline-none"
            />
          </div>
          <span className="text-xs text-stone-600 font-serif italic hidden sm:inline">
            {artwork.durationSeconds}초 힐링
          </span>
        </div>

        {/* Playback Controls & Action Buttons */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
          {/* Left: Play / Pause / Replay */}
          <div className="flex items-center gap-2">
            <button
              onClick={handlePlayPause}
              className="flex items-center gap-2 px-4 py-2 bg-stone-900 hover:bg-stone-800 text-white text-xs font-medium rounded-xl shadow-xs transition-all active:scale-95"
            >
              {isPlaying ? (
                <>
                  <Pause className="w-3.5 h-3.5 fill-current" />
                  <span>잠시 멈춤</span>
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>{progress >= 1.0 ? '다시 보기' : '이어 보기'}</span>
                </>
              )}
            </button>

            <button
              onClick={() => {
                setProgress(0);
                setIsPlaying(true);
              }}
              className="p-2 text-stone-600 hover:text-stone-900 hover:bg-stone-200/50 rounded-lg transition-colors"
              title="처음부터 다시 보기"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>

            {/* Speed Selector (Clean tabs) */}
            <div className="flex items-center p-0.5 bg-stone-200/70 rounded-lg text-xs font-medium text-stone-600">
              {[0.5, 1.0, 2.0, 4.0].map((speed) => (
                <button
                  key={speed}
                  onClick={() => setPlaybackSpeed(speed)}
                  className={`px-2 py-1 rounded-md transition-colors ${
                    playbackSpeed === speed
                      ? 'bg-white text-stone-900 font-semibold shadow-2xs'
                      : 'hover:text-stone-900'
                  }`}
                >
                  {speed}x
                </button>
              ))}
            </div>

            <button
              onClick={handleInstantFinish}
              className="px-2.5 py-1 text-xs text-stone-600 hover:text-stone-900 hover:bg-stone-200/50 rounded-lg transition-colors"
              title="즉시 완성본 보기"
            >
              완성
            </button>
          </div>

          {/* Right: Auto next toggle & Color Switch */}
          <div className="flex items-center gap-3">
            <label className="flex items-center gap-2 text-xs text-stone-600 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={autoNext}
                onChange={(e) => setAutoNext(e.target.checked)}
                className="rounded border-stone-300 text-stone-800 focus:ring-0"
              />
              <span>연속 멍때리기 (자동 넘김)</span>
            </label>

            <button
              onClick={() => onColorNow(artwork)}
              className="flex items-center gap-1.5 px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold rounded-xl shadow-xs transition-all active:scale-95"
            >
              <Palette className="w-3.5 h-3.5" />
              <span>이 도안 직접 칠하기</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// Canvas drawing helper for various artistic path types
function drawSinglePath(ctx: CanvasRenderingContext2D, path: DrawPath, style: string) {
  ctx.save();

  if (path.type === 'stroke') {
    ctx.strokeStyle = path.color;
    ctx.lineWidth = path.lineWidth || 1.8;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    if (style === 'pen') {
      ctx.globalAlpha = 0.92;
    } else if (style === 'oil') {
      ctx.globalAlpha = 0.95;
      ctx.shadowColor = 'rgba(0,0,0,0.15)';
      ctx.shadowBlur = 2;
    }

    const p = new Path2D(path.d);
    ctx.stroke(p);
  } else if (path.type === 'wash') {
    // Translucent watercolor wash or broad color block
    ctx.fillStyle = path.color;
    ctx.strokeStyle = path.color;
    ctx.lineWidth = path.lineWidth || 20;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.globalAlpha = 0.85;

    const p = new Path2D(path.d);
    ctx.fill(p);
    ctx.stroke(p);
  } else if (path.type === 'stipple') {
    // Stipple dots or flower pollen
    ctx.fillStyle = path.color;
    ctx.strokeStyle = path.color;
    ctx.lineWidth = path.lineWidth || 4;
    ctx.lineCap = 'round';

    const p = new Path2D(path.d);
    ctx.stroke(p);
  }

  ctx.restore();
}
