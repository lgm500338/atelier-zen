import React, { useState } from 'react';
import { Eye, Palette, Sparkles, Camera, Filter, Check } from 'lucide-react';
import { Artwork, ArtCategory, ArtDifficulty } from '../types/artwork';

interface GalleryViewProps {
  artworks: Artwork[];
  onSelectArtwork: (artwork: Artwork, mode: 'timelapse' | 'coloring') => void;
  onOpenPhotoModal: () => void;
  onGenerateProcedural: () => void;
}

export const GalleryView: React.FC<GalleryViewProps> = ({
  artworks,
  onSelectArtwork,
  onOpenPhotoModal,
  onGenerateProcedural
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>('all');
  const [selectedVolume, setSelectedVolume] = useState<string>('all');

  const categories: Array<{ id: string; label: string }> = [
    { id: 'all', label: '전체 도안' },
    { id: 'urban', label: '어반스케치 & 수채화' },
    { id: 'oil', label: '클래식 유화' },
    { id: 'botanical', label: '보태니컬 & 네이처' },
    { id: 'pop', label: '팝아트 & 모던' },
    { id: 'user', label: '내 사진 스케치' }
  ];

  const difficulties: Array<{ id: string; label: string }> = [
    { id: 'all', label: '모든 난이도' },
    { id: 'easy', label: '초급 (편안한 힐링)' },
    { id: 'medium', label: '중급 (몰입 힐링)' },
    { id: 'hard', label: '고급 (디테일 마스터)' }
  ];

  const filtered = artworks.filter((item) => {
    if (selectedCategory !== 'all' && item.category !== selectedCategory) return false;
    if (selectedDifficulty !== 'all' && item.difficulty !== selectedDifficulty) return false;
    if (selectedVolume !== 'all' && item.volume !== selectedVolume) return false;
    return true;
  });

  return (
    <div className="w-full max-w-7xl mx-auto px-4 md:px-8 py-6 space-y-6">
      {/* Editorial Curatorial Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-stone-200/80 pb-5">
        <div>
          <div className="text-xs tracking-wider uppercase text-stone-500 font-sans mb-1.5">
            MUSEUM ARCHIVE · VOLUME I & PROCEDURAL EDITIONS
          </div>
          <h1 className="font-serif text-3xl md:text-4xl font-medium text-stone-900 tracking-tight">
            아틀리에 도안 아카이브
          </h1>
          <p className="text-xs md:text-sm text-stone-600 mt-1 max-w-2xl leading-relaxed">
            마음을 비우고 드로잉 과정을 감상하는 <strong className="text-stone-800 font-medium">멍때리기 타임랩스</strong>와 나만의 색채를 입히는 <strong className="text-stone-800 font-medium">마인드풀 컬러링</strong> 중 원하는 방식으로 예술에 몰입해보세요.
          </p>
        </div>

        {/* Quick Creator CTA Bar */}
        <div className="flex items-center gap-2">
          <button
            onClick={onOpenPhotoModal}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-stone-700 bg-white hover:bg-stone-50 border border-stone-200/80 rounded-xl shadow-2xs transition-all whitespace-nowrap"
          >
            <Camera className="w-3.5 h-3.5 text-stone-600" />
            <span>내 사진 변환</span>
          </button>

          <button
            onClick={onGenerateProcedural}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-stone-900 bg-amber-100/80 hover:bg-amber-200/70 border border-amber-300/80 rounded-xl transition-all whitespace-nowrap shadow-2xs"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-700" />
            <span>새 도안 무한 생성</span>
          </button>
        </div>
      </div>

      {/* Filter Tabs Section (Clean functional tabs) */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-stone-100/70 p-2.5 rounded-2xl border border-stone-200/60">
        {/* Category Tabs */}
        <div className="flex flex-wrap items-center gap-1">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                selectedCategory === cat.id
                  ? 'bg-white text-stone-900 shadow-2xs font-semibold'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Difficulty Filter */}
        <div className="flex items-center gap-1.5 text-xs text-stone-600">
          <span className="text-stone-600 font-medium hidden sm:inline">난이도:</span>
          <select
            value={selectedDifficulty}
            onChange={(e) => setSelectedDifficulty(e.target.value)}
            className="bg-white border border-stone-200 text-stone-800 text-xs rounded-lg px-2.5 py-1 focus:outline-none"
          >
            {difficulties.map((diff) => (
              <option key={diff.id} value={diff.id}>
                {diff.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Artwork Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {filtered.map((item) => (
          <div
            key={item.id}
            className="group bg-[#FAF8F5] rounded-2xl overflow-hidden border border-stone-200/80 hover:border-stone-400/80 transition-all duration-300 canvas-paper-shadow flex flex-col justify-between"
          >
            {/* Thumbnail Canvas / Visual Frame */}
            <div className="relative aspect-4/3 bg-[#F4F1EA] overflow-hidden flex items-center justify-center p-3 border-b border-stone-200/60">
              {item.sourceImage ? (
                <img
                  src={item.sourceImage}
                  alt={item.title}
                  className="w-full h-full object-cover rounded-lg group-hover:scale-103 transition-transform duration-500"
                />
              ) : (
                <ArtworkMiniatureCanvas artwork={item} />
              )}

              {/* Hover quick overlay actions */}
              <div className="absolute inset-0 bg-stone-900/40 backdrop-blur-[2px] opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex items-center justify-center gap-2 p-4">
                <button
                  onClick={() => onSelectArtwork(item, 'timelapse')}
                  className="flex items-center gap-1.5 px-3 py-2 bg-white/95 hover:bg-white text-stone-900 text-xs font-medium rounded-xl shadow-lg transition-transform active:scale-95"
                >
                  <Eye className="w-3.5 h-3.5 text-amber-700" />
                  <span>멍때리기 감상</span>
                </button>
                <button
                  onClick={() => onSelectArtwork(item, 'coloring')}
                  className="flex items-center gap-1.5 px-3 py-2 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold rounded-xl shadow-lg transition-transform active:scale-95"
                >
                  <Palette className="w-3.5 h-3.5" />
                  <span>직접 칠하기</span>
                </button>
              </div>

              {/* Top metadata badge */}
              <div className="absolute top-2.5 left-2.5 px-2.5 py-1 bg-stone-900/70 backdrop-blur-xs rounded-md text-white text-2xs font-medium tracking-tight">
                {item.volume}
              </div>
            </div>

            {/* Content Details */}
            <div className="p-4 space-y-2 flex-1 flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2 text-2xs text-stone-500 mb-1">
                  <span>{item.categoryName}</span>
                  <span aria-hidden="true">·</span>
                  <span>{item.difficultyName}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono">{item.durationSeconds}초</span>
                </div>
                <h3 className="font-serif text-lg font-medium text-stone-900 leading-snug group-hover:text-amber-900 transition-colors">
                  {item.title}
                </h3>
                <p className="text-xs text-stone-600 line-clamp-2 mt-1 leading-relaxed">
                  {item.description}
                </p>
              </div>

              {/* Color Swatch Dots & Action row */}
              <div className="pt-3 border-t border-stone-200/60 flex items-center justify-between">
                <div className="flex items-center -space-x-1">
                  {item.palette.slice(0, 5).map((color, cIdx) => (
                    <span
                      key={cIdx}
                      className="w-4 h-4 rounded-full border border-white shadow-2xs"
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onSelectArtwork(item, 'timelapse')}
                    className="p-1.5 text-stone-600 hover:text-stone-900 rounded-lg hover:bg-stone-200/50 transition-colors"
                    title="멍때리기 감상"
                  >
                    <Eye className="w-4 h-4 text-amber-700" />
                  </button>
                  <button
                    onClick={() => onSelectArtwork(item, 'coloring')}
                    className="p-1.5 text-stone-600 hover:text-emerald-700 rounded-lg hover:bg-emerald-50 transition-colors"
                    title="직접 컬러링"
                  >
                    <Palette className="w-4 h-4 text-emerald-700" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-16 bg-stone-100/40 rounded-2xl border border-dashed border-stone-300">
          <p className="text-stone-500 text-sm">해당 조건의 도안이 아직 없습니다.</p>
          <button
            onClick={onGenerateProcedural}
            className="mt-3 px-4 py-2 bg-stone-900 text-white text-xs font-medium rounded-xl hover:bg-stone-800 transition-colors inline-flex items-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>새 도안 알고리즘 생성하기</span>
          </button>
        </div>
      )}
    </div>
  );
};

// Lightweight static thumbnail renderer using canvas
const ArtworkMiniatureCanvas: React.FC<{ artwork: Artwork }> = ({ artwork }) => {
  const canvasRef = React.useRef<HTMLCanvasElement | null>(null);

  React.useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, artwork.width, artwork.height);
    ctx.fillStyle = '#FAF7F2';
    ctx.fillRect(0, 0, artwork.width, artwork.height);

    artwork.layers.forEach((layer) => {
      layer.paths.forEach((path) => {
        ctx.save();
        if (path.type === 'stroke') {
          ctx.strokeStyle = path.color;
          ctx.lineWidth = path.lineWidth || 1.8;
          ctx.lineCap = 'round';
          ctx.stroke(new Path2D(path.d));
        } else if (path.type === 'wash') {
          ctx.fillStyle = path.color;
          ctx.strokeStyle = path.color;
          ctx.lineWidth = path.lineWidth || 20;
          ctx.globalAlpha = 0.8;
          const p = new Path2D(path.d);
          ctx.fill(p);
          ctx.stroke(p);
        }
        ctx.restore();
      });
    });
  }, [artwork]);

  return (
    <canvas
      ref={canvasRef}
      width={artwork.width}
      height={artwork.height}
      className="w-full h-full object-contain block rounded-lg select-none"
    />
  );
};
