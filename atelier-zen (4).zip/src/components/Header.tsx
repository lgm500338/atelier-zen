import React, { useState } from 'react';
import { Volume2, VolumeX, Sparkles, Camera, Palette, Eye, BookOpen, Music } from 'lucide-react';
import { sound } from '../utils/audio';

interface HeaderProps {
  currentTab: 'timelapse' | 'coloring' | 'gallery';
  setCurrentTab: (tab: 'timelapse' | 'coloring' | 'gallery') => void;
  onOpenPhotoModal: () => void;
  onGenerateProcedural: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  setCurrentTab,
  onOpenPhotoModal,
  onGenerateProcedural
}) => {
  const [isMuted, setIsMuted] = useState(sound.getMuted());
  const [bgmActive, setBgmActive] = useState(false);

  const toggleMute = () => {
    const next = !isMuted;
    setIsMuted(next);
    sound.setMuted(next);
    if (next && bgmActive) {
      setBgmActive(false);
      sound.toggleAmbientMusic(false);
    }
  };

  const toggleBgm = () => {
    if (isMuted) {
      setIsMuted(false);
      sound.setMuted(false);
    }
    const next = !bgmActive;
    setBgmActive(next);
    sound.toggleAmbientMusic(next);
  };

  return (
    <header
      style={{ paddingTop: 'calc(var(--sat, 0px) + 0.5rem)' }}
      className="sticky top-0 z-40 bg-[#F7F5F0]/95 backdrop-blur-md border-b border-stone-200/80 px-3 sm:px-6 md:px-8 pb-2.5 sm:pb-3 transition-colors"
    >
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 sm:gap-4">
        {/* Top bar on mobile / Left branding on sm+ */}
        <div className="flex items-center justify-between w-full sm:w-auto gap-2">
          {/* Logo */}
          <button
            onClick={() => setCurrentTab('timelapse')}
            className="text-left group flex items-baseline gap-2 text-stone-900 focus-visible:outline-none cursor-pointer shrink-0"
          >
            <span className="font-serif text-xl sm:text-2xl md:text-3xl font-semibold tracking-tight text-stone-900 group-hover:text-stone-700 transition-colors">
              Atelier Zen
            </span>
            <span className="hidden md:inline text-[11px] tracking-wider uppercase text-stone-500 font-medium">
              아틀리에 젠
            </span>
          </button>

          {/* Action buttons (Row 1 on mobile, grouped on right) */}
          <div className="flex items-center gap-1 sm:hidden">
            {/* Photo Converter Button */}
            <button
              onClick={onOpenPhotoModal}
              className="p-1.5 text-stone-700 bg-white hover:bg-stone-50 border border-stone-200/80 rounded-lg shadow-2xs transition-colors cursor-pointer"
              title="내 사진을 100% 로컬에서 스케치로 변환"
              aria-label="사진 스케치 변환"
            >
              <Camera className="w-4 h-4 text-stone-600" />
            </button>

            {/* Infinite Procedural Generator */}
            <button
              onClick={onGenerateProcedural}
              className="p-1.5 text-stone-800 bg-amber-50 hover:bg-amber-100/70 border border-amber-200/80 rounded-lg transition-colors cursor-pointer"
              title="수학 알고리즘으로 무한한 새 도안 생성"
              aria-label="무한 도안 생성"
            >
              <Sparkles className="w-4 h-4 text-amber-700" />
            </button>

            {/* Ambient BGM toggle */}
            <button
              onClick={toggleBgm}
              className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
                bgmActive
                  ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                  : 'bg-white border-stone-200 text-stone-500 hover:text-stone-800'
              }`}
              title={bgmActive ? '선율 BGM 켜짐' : '잔잔한 명상 BGM 켜기'}
              aria-label="명상 BGM 켜기/끄기"
            >
              <Music className="w-4 h-4" />
            </button>

            {/* Sound Mute/Unmute */}
            <button
              onClick={toggleMute}
              className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
                isMuted
                  ? 'bg-stone-100 border-stone-200 text-stone-400'
                  : 'bg-white border-stone-200 text-stone-700 hover:bg-stone-50'
              }`}
              title={isMuted ? '소리 켜기' : '사각사각 ASMR 음소거'}
              aria-label="소리 켜기/끄기"
            >
              {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-amber-700" />}
            </button>
          </div>
        </div>

        {/* Navigation Tabs (Row 2 on mobile: full width grid, centered on sm+) */}
        <nav className="w-full sm:w-auto grid grid-cols-3 sm:flex items-center p-1 bg-stone-200/60 rounded-xl border border-stone-300/40 gap-1">
          <button
            onClick={() => setCurrentTab('timelapse')}
            className={`flex items-center justify-center gap-1 sm:gap-1.5 px-2 sm:px-3 py-1.5 text-xs sm:text-sm font-medium rounded-lg transition-all cursor-pointer whitespace-nowrap ${
              currentTab === 'timelapse'
                ? 'bg-white text-stone-900 shadow-xs font-semibold'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <Eye className="w-3.5 h-3.5 text-amber-700 shrink-0" />
            <span className="sm:hidden">감상</span>
            <span className="hidden sm:inline">멍때리는 아틀리에</span>
          </button>

          <button
            onClick={() => setCurrentTab('coloring')}
            className={`flex items-center justify-center gap-1 sm:gap-1.5 px-2 sm:px-3 py-1.5 text-xs sm:text-sm font-medium rounded-lg transition-all cursor-pointer whitespace-nowrap ${
              currentTab === 'coloring'
                ? 'bg-white text-stone-900 shadow-xs font-semibold'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <Palette className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
            <span className="sm:hidden">컬러링</span>
            <span className="hidden sm:inline">컬러링 스튜디오</span>
          </button>

          <button
            onClick={() => setCurrentTab('gallery')}
            className={`flex items-center justify-center gap-1 sm:gap-1.5 px-2 sm:px-3 py-1.5 text-xs sm:text-sm font-medium rounded-lg transition-all cursor-pointer whitespace-nowrap ${
              currentTab === 'gallery'
                ? 'bg-white text-stone-900 shadow-xs font-semibold'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5 text-blue-700 shrink-0" />
            <span className="sm:hidden">스케치북</span>
            <span className="hidden sm:inline">내 스케치북</span>
          </button>
        </nav>

        {/* Action Buttons on sm+ screen */}
        <div className="hidden sm:flex items-center gap-2">
          {/* Photo Converter Button */}
          <button
            onClick={onOpenPhotoModal}
            className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-stone-700 bg-white hover:bg-stone-50 border border-stone-200/80 rounded-lg shadow-2xs transition-colors cursor-pointer whitespace-nowrap"
            title="내 사진을 100% 로컬에서 스케치로 변환"
          >
            <Camera className="w-3.5 h-3.5 text-stone-600" />
            <span className="hidden md:inline">사진 변환</span>
          </button>

          {/* Infinite Procedural Generator */}
          <button
            onClick={onGenerateProcedural}
            className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-stone-800 bg-amber-50 hover:bg-amber-100/70 border border-amber-200/80 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
            title="수학 알고리즘으로 무한한 새 도안 생성"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-700" />
            <span className="hidden md:inline">새 도안</span>
          </button>

          {/* Ambient BGM toggle */}
          <button
            onClick={toggleBgm}
            className={`p-2 text-xs rounded-lg border transition-colors cursor-pointer ${
              bgmActive
                ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                : 'bg-white border-stone-200 text-stone-500 hover:text-stone-800'
            }`}
            title={bgmActive ? '선율 BGM 켜짐' : '잔잔한 명상 BGM 켜기'}
            aria-label="명상 BGM 켜기/끄기"
          >
            <Music className="w-3.5 h-3.5" />
          </button>

          {/* Sound Mute/Unmute */}
          <button
            onClick={toggleMute}
            className={`p-2 text-xs rounded-lg border transition-colors cursor-pointer ${
              isMuted
                ? 'bg-stone-100 border-stone-200 text-stone-400'
                : 'bg-white border-stone-200 text-stone-700 hover:bg-stone-50'
            }`}
            title={isMuted ? '소리 켜기' : '사각사각 ASMR 음소거'}
            aria-label="소리 켜기/끄기"
          >
            {isMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5 text-amber-700" />}
          </button>
        </div>
      </div>
    </header>
  );
};
