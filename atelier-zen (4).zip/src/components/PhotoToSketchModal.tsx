import React, { useState, useRef } from 'react';
import { X, Upload, Sliders, Sparkles, Check, Image as ImageIcon, Eye, Palette } from 'lucide-react';
import { convertPhotoToArtwork, PhotoSketchOptions } from '../utils/photoToSketch';
import { Artwork } from '../types/artwork';
import { sound } from '../utils/audio';

interface PhotoToSketchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onArtworkReady: (artwork: Artwork, mode: 'timelapse' | 'coloring') => void;
}

export const PhotoToSketchModal: React.FC<PhotoToSketchModalProps> = ({
  isOpen,
  onClose,
  onArtworkReady
}) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewSrc, setPreviewSrc] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);

  // Settings
  const [options, setOptions] = useState<PhotoSketchOptions>({
    detailLevel: 'medium',
    contrast: 1.3,
    threshold: 48,
    colorWash: true
  });

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSelectedFile(file);
      const url = URL.createObjectURL(file);
      setPreviewSrc(url);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      setSelectedFile(file);
      const url = URL.createObjectURL(file);
      setPreviewSrc(url);
    }
  };

  const handleConvert = async (mode: 'timelapse' | 'coloring') => {
    if (!selectedFile) return;
    setIsProcessing(true);
    sound.playPencilScratch(0.08);

    try {
      const converted = await convertPhotoToArtwork(selectedFile, options);
      sound.playZenChime(523.25, 2.5, 0.08);
      setIsProcessing(false);
      onArtworkReady(converted, mode);
      onClose();
    } catch (err) {
      console.error(err);
      setIsProcessing(false);
    }
  };

  return (
    <div
      style={{
        paddingTop: 'max(1rem, var(--sat, 0px))',
        paddingBottom: 'max(1rem, var(--sab, 0px))',
        paddingLeft: 'max(1rem, var(--sal, 0px))',
        paddingRight: 'max(1rem, var(--sar, 0px))',
      }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-xs animate-in fade-in duration-200 overflow-y-auto"
    >
      <div className="bg-[#FAF8F5] border border-stone-200/90 rounded-2xl max-w-xl w-full p-6 shadow-2xl relative">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 text-stone-400 hover:text-stone-700 rounded-lg hover:bg-stone-200/50 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="mb-5">
          <div className="flex items-center gap-2 text-xs text-amber-700 font-medium mb-1">
            <Sparkles className="w-3.5 h-3.5" />
            <span>100% 로컬 연산 · API 호출 없음 · 개인정보 안심</span>
          </div>
          <h3 className="font-serif text-2xl font-medium text-stone-900">
            내 사진을 스케치 & 컬러링 도안으로 변환
          </h3>
          <p className="text-xs text-stone-600 mt-1 leading-relaxed">
            여행 풍경, 우리 집, 꽃, 반려동물 사진을 올려보세요. 브라우저 컴퓨터 그래픽스 알고리즘이 펜 스케치 선화로 즉시 추출합니다.
          </p>
        </div>

        {/* Dropzone / Preview */}
        <div
          onDragOver={(e) => e.preventDefault()}
          onDrop={handleDrop}
          onClick={() => !previewSrc && fileInputRef.current?.click()}
          className={`border-2 border-dashed rounded-xl p-4 flex flex-col items-center justify-center transition-all cursor-pointer min-h-[170px] ${
            previewSrc
              ? 'border-stone-300 bg-white'
              : 'border-stone-300 hover:border-stone-400 bg-stone-100/50'
          }`}
        >
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleFileChange}
            className="hidden"
          />

          {previewSrc ? (
            <div className="relative w-full flex flex-col items-center">
              <img
                src={previewSrc}
                alt="Upload preview"
                className="max-h-48 rounded-lg object-contain border border-stone-200 shadow-2xs"
              />
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedFile(null);
                  setPreviewSrc(null);
                }}
                className="mt-2 text-xs text-stone-500 hover:text-stone-800 underline"
              >
                다른 사진으로 변경
              </button>
            </div>
          ) : (
            <div className="text-center space-y-2 py-4">
              <div className="w-12 h-12 mx-auto rounded-full bg-stone-200/80 flex items-center justify-center text-stone-600">
                <Upload className="w-6 h-6" />
              </div>
              <div className="text-sm font-medium text-stone-800">
                사진을 끌어다 놓거나 클릭하여 선택
              </div>
              <div className="text-xs text-stone-600">JPG, PNG, WebP 사진 지원</div>
            </div>
          )}
        </div>

        {/* Controls / Options */}
        {selectedFile && (
          <div className="mt-4 space-y-3 pt-3 border-t border-stone-200/80">
            {/* Detail Level Tabs */}
            <div>
              <label className="text-xs font-medium text-stone-700 block mb-1.5">
                펜 선 스타일
              </label>
              <div className="flex gap-2">
                {[
                  { id: 'fine', label: '세밀한 펜선' },
                  { id: 'medium', label: '어반스케치 펜' },
                  { id: 'bold', label: '굵은 라인' }
                ].map((d) => (
                  <button
                    key={d.id}
                    onClick={() =>
                      setOptions((prev) => ({
                        ...prev,
                        detailLevel: d.id as PhotoSketchOptions['detailLevel']
                      }))
                    }
                    className={`flex-1 py-1.5 text-xs font-medium rounded-lg border transition-colors ${
                      options.detailLevel === d.id
                        ? 'bg-stone-900 text-white border-stone-900 shadow-2xs'
                        : 'bg-white text-stone-700 border-stone-200 hover:bg-stone-50'
                    }`}
                  >
                    {d.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Threshold & Contrast */}
            <div className="grid grid-cols-2 gap-3 text-xs text-stone-600">
              <div>
                <div className="flex justify-between mb-1">
                  <span>윤곽선 민감도</span>
                  <span className="font-mono">{options.threshold}</span>
                </div>
                <input
                  type="range"
                  min="25"
                  max="90"
                  value={options.threshold}
                  onChange={(e) =>
                    setOptions((prev) => ({ ...prev, threshold: parseInt(e.target.value) }))
                  }
                  className="w-full h-1 bg-stone-200 rounded appearance-none accent-stone-800"
                />
              </div>

              <div>
                <div className="flex justify-between mb-1">
                  <span>명암 대비</span>
                  <span className="font-mono">{options.contrast.toFixed(1)}x</span>
                </div>
                <input
                  type="range"
                  min="0.8"
                  max="2.0"
                  step="0.1"
                  value={options.contrast}
                  onChange={(e) =>
                    setOptions((prev) => ({ ...prev, contrast: parseFloat(e.target.value) }))
                  }
                  className="w-full h-1 bg-stone-200 rounded appearance-none accent-stone-800"
                />
              </div>
            </div>

            {/* Watercolor Wash Checkbox */}
            <label className="flex items-center gap-2 text-xs text-stone-700 cursor-pointer pt-1">
              <input
                type="checkbox"
                checked={options.colorWash}
                onChange={(e) =>
                  setOptions((prev) => ({ ...prev, colorWash: e.target.checked }))
                }
                className="rounded border-stone-300 text-stone-900 focus:ring-0"
              />
              <span>사진 본연의 색상으로 맑은 수채화 언더톤 생성</span>
            </label>
          </div>
        )}

        {/* Footer Actions */}
        <div className="mt-6 flex flex-col sm:flex-row items-center justify-end gap-2 pt-3 border-t border-stone-200/80">
          <button
            onClick={onClose}
            className="w-full sm:w-auto px-4 py-2 text-xs font-medium text-stone-600 hover:text-stone-900 hover:bg-stone-100 rounded-lg transition-colors"
          >
            취소
          </button>

          <button
            onClick={() => handleConvert('timelapse')}
            disabled={!selectedFile || isProcessing}
            className="w-full sm:w-auto flex items-center justify-center gap-1.5 px-4 py-2 text-xs font-medium text-stone-800 bg-stone-200 hover:bg-stone-300 disabled:opacity-40 rounded-xl transition-all"
          >
            <Eye className="w-3.5 h-3.5 text-amber-800" />
            <span>{isProcessing ? '변환 중...' : '스케치 과정 멍때리기'}</span>
          </button>

          <button
            onClick={() => handleConvert('coloring')}
            disabled={!selectedFile || isProcessing}
            className="w-full sm:w-auto flex items-center justify-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 disabled:opacity-40 rounded-xl shadow-xs transition-all"
          >
            <Palette className="w-3.5 h-3.5" />
            <span>{isProcessing ? '변환 중...' : '바로 컬러링하기'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
