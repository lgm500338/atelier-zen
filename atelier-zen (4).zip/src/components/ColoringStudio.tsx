import React, { useRef, useState, useEffect, useCallback } from 'react';
import {
  Undo,
  Redo,
  Download,
  RotateCcw,
  ZoomIn,
  ZoomOut,
  Maximize2,
  Droplet,
  Paintbrush,
  PenTool,
  PaintBucket,
  Eraser,
  Save,
  Play,
  Volume2,
  Sparkles,
  Check,
  Pencil,
  Highlighter,
  Wind,
  Blend,
  Layers,
  AlertCircle
} from 'lucide-react';
import { Artwork, SavedPainting } from '../types/artwork';
import { sound } from '../utils/audio';
import { saveArtworkImage } from '../utils/tossBridge';

interface ColoringStudioProps {
  artwork: Artwork;
  onSaveToGallery: (painting: SavedPainting) => boolean | void;
  onBackToTimelapse: () => void;
}

export type ToolMode =
  | 'watercolor'
  | 'oil'
  | 'acrylic'
  | 'pencil'
  | 'pastel'
  | 'marker'
  | 'airbrush'
  | 'pen'
  | 'blender'
  | 'fill'
  | 'eraser';

interface StrokeRecord {
  type: ToolMode;
  color: string;
  size: number;
  opacity: number;
  points: Array<{ x: number; y: number }>;
}

interface ToolDefinition {
  id: ToolMode;
  name: string;
  category: '회화' | '드로잉' | '스튜디오';
  desc: string;
  artTip: string;
  badge: string;
  sizeLabel: string;
  opacityLabel: string;
  defaultSize: number;
  defaultOpacity: number;
}

const TOOL_DEFINITIONS: ToolDefinition[] = [
  {
    id: 'watercolor',
    name: '수채화',
    category: '회화',
    desc: '맑고 촉촉한 투명 번짐',
    artTip: '덧칠할수록 물감이 겹쳐지며 깊은 투명 음영(Glazing)이 생깁니다.',
    badge: '맑은 번짐',
    sizeLabel: '붓 굵기',
    opacityLabel: '물감 농도 / 물 조절',
    defaultSize: 26,
    defaultOpacity: 0.55
  },
  {
    id: 'oil',
    name: '유화',
    category: '회화',
    desc: '도톰한 임파스토 3D 질감',
    artTip: '물감 하이라이트 광택이 입체적으로 살아있어 유화 특유의 마티에르가 표현됩니다.',
    badge: '입체 마티에르',
    sizeLabel: '유화 붓 굵기',
    opacityLabel: '물감 도포 두께',
    defaultSize: 28,
    defaultOpacity: 0.9
  },
  {
    id: 'acrylic',
    name: '아크릴화',
    category: '회화',
    desc: '선명한 고발색 & 붓결 텍스처',
    artTip: '빠르게 건조되어 밑색을 깨끗하게 덮고, 섬세한 인조모 브러시 결 자국이 남습니다.',
    badge: '붓결 텍스처',
    sizeLabel: '아크릴 평붓 굵기',
    opacityLabel: '물감 덮임도 (Coverage)',
    defaultSize: 24,
    defaultOpacity: 0.85
  },
  {
    id: 'pencil',
    name: '색연필',
    category: '드로잉',
    desc: '종이 결이 살아있는 서걱 질감',
    artTip: '스케치북 요철 위를 지나는 왁스 색연필 터치로 잔잔하고 서정적인 그라데이션을 냅니다.',
    badge: '종이 결 ASMR',
    sizeLabel: '색연필 심 굵기',
    opacityLabel: '필압 (누르는 힘)',
    defaultSize: 16,
    defaultOpacity: 0.7
  },
  {
    id: 'pastel',
    name: '오일파스텔',
    category: '드로잉',
    desc: '크리미하고 부드러운 뭉개짐',
    artTip: '도톰하고 몽글몽글하게 얹히는 크레용 분필 느낌으로 따뜻한 감성을 그립니다.',
    badge: '크리미 파우더',
    sizeLabel: '파스텔 굵기',
    opacityLabel: '파우더 밀도',
    defaultSize: 22,
    defaultOpacity: 0.75
  },
  {
    id: 'marker',
    name: '알코올 마커',
    category: '회화',
    desc: '어반스케치용 반투명 사각 팁',
    artTip: '디자인 코픽 마커처럼 45도 각도의 넓은 닙으로 군더더기 없이 깔끔하게 채웁니다.',
    badge: '일러스트 닙',
    sizeLabel: '마커 닙 너비',
    opacityLabel: '잉크 투명도',
    defaultSize: 24,
    defaultOpacity: 0.5
  },
  {
    id: 'airbrush',
    name: '에어브러시',
    category: '드로잉',
    desc: '몽환적인 안개 분사 그라데이션',
    artTip: '부드러운 미세 입자로 노을빛 하늘이나 은은한 볼터치, 빛의 후광을 만듭니다.',
    badge: '안개 분사',
    sizeLabel: '분사 반경',
    opacityLabel: '분사 밀도 / 압력',
    defaultSize: 38,
    defaultOpacity: 0.38
  },
  {
    id: 'pen',
    name: '세밀 펜선',
    category: '드로잉',
    desc: '또렷한 잉크 펜 & 해칭',
    artTip: '날렵한 피그먼트 라이너 선으로 세밀한 디테일, 크로스해칭 음영, 서명을 더합니다.',
    badge: '샤프 잉크',
    sizeLabel: '펜촉 굵기',
    opacityLabel: '잉크 진함',
    defaultSize: 12,
    defaultOpacity: 0.95
  },
  {
    id: 'blender',
    name: '블렌더 (찰필)',
    category: '스튜디오',
    desc: '경계를 부드럽게 문질러 섞기',
    artTip: '물붓이나 찰필처럼 칠해진 색들의 경계를 부드럽게 이어주는 마법의 믹싱 도구입니다.',
    badge: '부드러운 믹싱',
    sizeLabel: '문지름 반경',
    opacityLabel: '블렌딩 강도',
    defaultSize: 28,
    defaultOpacity: 0.65
  },
  {
    id: 'fill',
    name: '구역 채색',
    category: '스튜디오',
    desc: '펜선 안쪽 탭 한 번에 채우기',
    artTip: '스케치 외곽선을 침범하지 않고 맑은 톤으로 원하는 면을 빠르게 채색합니다.',
    badge: '스마트 채움',
    sizeLabel: '채색 허용치',
    opacityLabel: '채색 투명도',
    defaultSize: 20,
    defaultOpacity: 0.7
  },
  {
    id: 'eraser',
    name: '지우개',
    category: '스튜디오',
    desc: '밑그림 보존 채색 지우개',
    artTip: '검은 스케치 펜선은 안전하게 보호한 채 칠해진 물감만 깨끗하게 지웁니다.',
    badge: '원상 복구',
    sizeLabel: '지우개 크기',
    opacityLabel: '지우개 강도',
    defaultSize: 26,
    defaultOpacity: 1.0
  }
];

export const ColoringStudio: React.FC<ColoringStudioProps> = ({
  artwork,
  onSaveToGallery,
  onBackToTimelapse
}) => {
  // Canvases
  const paintCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const outlineCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Tools & Settings
  const [tool, setTool] = useState<ToolMode>('watercolor');
  const [toolCategoryTab, setToolCategoryTab] = useState<'all' | '회화' | '드로잉' | '스튜디오'>('all');
  const [selectedColor, setSelectedColor] = useState<string>(artwork.palette[0] || '#4A7C59');
  const [brushSize, setBrushSize] = useState<number>(24);
  const [brushOpacity, setBrushOpacity] = useState<number>(0.65); // 0.1 to 1.0

  // Active tool config
  const activeToolDef = TOOL_DEFINITIONS.find((t) => t.id === tool) || TOOL_DEFINITIONS[0];

  // History & Replay
  const [history, setHistory] = useState<ImageData[]>([]);
  const [historyIndex, setHistoryIndex] = useState<number>(-1);
  const strokesRef = useRef<StrokeRecord[]>([]);
  const isDrawing = useRef<boolean>(false);
  const currentPoints = useRef<Array<{ x: number; y: number }>>([]);

  // Zoom & Pan
  const [zoom, setZoom] = useState<number>(1.0);
  const [pan, setPan] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isPanning, setIsPanning] = useState<boolean>(false);

  // Replay modal state
  const [isReplaying, setIsReplaying] = useState<boolean>(false);
  const [savedNotification, setSavedNotification] = useState<boolean>(false);
  const [saveErrorMessage, setSaveErrorMessage] = useState<string | null>(null);

  // Palettes
  const curatedPalettes = [
    { name: '작품 추천 팔레트', colors: artwork.palette },
    { name: '어반 숲 & 전원', colors: ['#4A7C59', '#8CB369', '#D4E09B', '#C94A29', '#E09F3E', '#5B85AA', '#F4F1DE', '#333333'] },
    { name: '모네의 수련', colors: ['#2A4736', '#416D54', '#7BA082', '#9BB7A6', '#D68C9E', '#EBBAB9', '#F9E4B7', '#457B9D'] },
    { name: '고흐의 밤', colors: ['#0B1B3D', '#1B3B6F', '#4299E1', '#F49E4C', '#F5EE9E', '#283618', '#606C38', '#FFFFFF'] },
    { name: '보태니컬 힐링', colors: ['#2D4739', '#4E6E58', '#739E82', '#A3C4BC', '#DDA15E', '#BC6C25', '#FAF7F2', '#1E3326'] }
  ];

  // Draw outline layer once
  useEffect(() => {
    const canvas = outlineCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, artwork.width, artwork.height);

    // Draw only pen/sketch layers onto the top outline canvas
    artwork.layers.forEach((layer) => {
      if (layer.style === 'pen') {
        layer.paths.forEach((path) => {
          if (path.type === 'stroke') {
            ctx.save();
            ctx.strokeStyle = path.color;
            ctx.lineWidth = path.lineWidth || 1.8;
            ctx.lineCap = 'round';
            ctx.lineJoin = 'round';
            ctx.stroke(new Path2D(path.d));
            ctx.restore();
          }
        });
      }
    });

    // Initialize paint canvas with initial paper wash
    initPaintCanvas();
  }, [artwork]);

  const initPaintCanvas = useCallback(() => {
    const canvas = paintCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;

    ctx.clearRect(0, 0, artwork.width, artwork.height);

    // Initial warm paper fill
    ctx.fillStyle = '#FAF7F2';
    ctx.fillRect(0, 0, artwork.width, artwork.height);

    // Save initial state to history
    const initialData = ctx.getImageData(0, 0, artwork.width, artwork.height);
    setHistory([initialData]);
    setHistoryIndex(0);
    strokesRef.current = [];
  }, [artwork]);

  const saveStateToHistory = () => {
    const canvas = paintCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;

    const imgData = ctx.getImageData(0, 0, artwork.width, artwork.height);
    setHistory((prev) => {
      const trimmed = prev.slice(0, historyIndex + 1);
      return [...trimmed, imgData];
    });
    setHistoryIndex((prev) => prev + 1);
  };

  const handleUndo = () => {
    if (historyIndex > 0) {
      const nextIndex = historyIndex - 1;
      const canvas = paintCanvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      ctx.putImageData(history[nextIndex], 0, 0);
      setHistoryIndex(nextIndex);
      sound.playPencilScratch(0.04);
    }
  };

  const handleRedo = () => {
    if (historyIndex < history.length - 1) {
      const nextIndex = historyIndex + 1;
      const canvas = paintCanvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      ctx.putImageData(history[nextIndex], 0, 0);
      setHistoryIndex(nextIndex);
      sound.playPencilScratch(0.04);
    }
  };

  // Sound dispatcher for authentic brush ASMR
  const playBrushAudio = (toolType: ToolMode, isStart = false) => {
    const vol = isStart ? 0.08 : 0.04;
    switch (toolType) {
      case 'pencil':
        sound.playColoredPencil(vol * 1.1);
        break;
      case 'acrylic':
        sound.playAcrylic(vol);
        break;
      case 'pastel':
        sound.playPastelChalk(vol);
        break;
      case 'marker':
        sound.playMarker(vol);
        break;
      case 'airbrush':
        sound.playAirbrush(vol);
        break;
      case 'blender':
        sound.playBlender(vol);
        break;
      case 'pen':
        sound.playPencilScratch(vol);
        break;
      case 'oil':
        sound.playAcrylic(vol * 0.9);
        break;
      case 'watercolor':
      default:
        sound.playWaterBrush(vol);
        break;
    }
  };

  // Coordinates translation from event to canvas space (accounting for object-contain offsets)
  const getCanvasCoords = (e: React.MouseEvent<HTMLDivElement> | React.TouchEvent<HTMLDivElement>) => {
    const canvas = paintCanvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();

    let clientX = 0;
    let clientY = 0;

    if ('touches' in e && e.touches.length > 0) {
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else if ('clientX' in e) {
      clientX = e.clientX;
      clientY = e.clientY;
    }

    const scale = Math.min(rect.width / canvas.width, rect.height / canvas.height);
    const offsetX = (rect.width - canvas.width * scale) / 2;
    const offsetY = (rect.height - canvas.height * scale) / 2;

    return {
      x: (clientX - rect.left - offsetX) / scale,
      y: (clientY - rect.top - offsetY) / scale
    };
  };

  // Switch tool and apply artistic defaults
  const handleSelectTool = (targetTool: ToolMode) => {
    setTool(targetTool);
    const def = TOOL_DEFINITIONS.find((t) => t.id === targetTool);
    if (def) {
      setBrushSize(def.defaultSize);
      setBrushOpacity(def.defaultOpacity);
    }
    playBrushAudio(targetTool, true);
  };

  // Real-time canvas stroke rendering for all 11 media
  const renderBrushSegment = (
    ctx: CanvasRenderingContext2D,
    toolType: ToolMode,
    p1: { x: number; y: number },
    p2: { x: number; y: number },
    color: string,
    size: number,
    opacity: number
  ) => {
    ctx.save();

    if (toolType === 'eraser') {
      // Clean eraser on paint layer without touching outline
      ctx.globalCompositeOperation = 'destination-out';
      ctx.strokeStyle = 'rgba(0,0,0,1)';
      ctx.lineWidth = size * 1.4;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.beginPath();
      ctx.moveTo(p1.x, p1.y);
      ctx.lineTo(p2.x, p2.y);
      ctx.stroke();
    } else if (toolType === 'watercolor') {
      // 1. Watercolor: Translucent, watery wash with soft radial shadow bleed
      ctx.strokeStyle = color;
      ctx.lineWidth = size;
      ctx.globalAlpha = opacity * 0.45;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.shadowColor = color;
      ctx.shadowBlur = size * 0.25;

      ctx.beginPath();
      ctx.moveTo(p1.x, p1.y);
      ctx.lineTo(p2.x, p2.y);
      ctx.stroke();
    } else if (toolType === 'oil') {
      // 2. Oil Impasto: Thick 3D impasto with bevel ridge shine
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';

      // Base thick paint
      ctx.strokeStyle = color;
      ctx.lineWidth = size;
      ctx.globalAlpha = Math.min(1.0, opacity * 1.15);
      ctx.shadowColor = 'rgba(0,0,0,0.18)';
      ctx.shadowBlur = 4;
      ctx.beginPath();
      ctx.moveTo(p1.x, p1.y);
      ctx.lineTo(p2.x, p2.y);
      ctx.stroke();

      // Top impasto knife ridge highlight
      const angle = Math.atan2(p2.y - p1.y, p2.x - p1.x);
      const perpX = Math.cos(angle + Math.PI / 2) * (size * 0.22);
      const perpY = Math.sin(angle + Math.PI / 2) * (size * 0.22);

      ctx.shadowColor = 'transparent';
      ctx.strokeStyle = 'rgba(255,255,255,0.25)';
      ctx.lineWidth = size * 0.28;
      ctx.beginPath();
      ctx.moveTo(p1.x + perpX, p1.y + perpY);
      ctx.lineTo(p2.x + perpX, p2.y + perpY);
      ctx.stroke();
    } else if (toolType === 'acrylic') {
      // 3. Acrylic: High coverage, fast drying with synthetic bristle grooves
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';

      // Solid base stroke
      ctx.strokeStyle = color;
      ctx.lineWidth = size;
      ctx.globalAlpha = Math.min(0.96, opacity * 0.9);
      ctx.beginPath();
      ctx.moveTo(p1.x, p1.y);
      ctx.lineTo(p2.x, p2.y);
      ctx.stroke();

      // Parallel fine bristle marks (붓결 스트로크)
      const angle = Math.atan2(p2.y - p1.y, p2.x - p1.x);
      const perpX = Math.cos(angle + Math.PI / 2);
      const perpY = Math.sin(angle + Math.PI / 2);
      const bristleCount = Math.max(3, Math.floor(size / 5));

      for (let b = -bristleCount / 2; b <= bristleCount / 2; b++) {
        const offset = (b / (bristleCount / 2)) * (size * 0.42);
        const isLight = Math.abs(b) % 2 === 0;
        ctx.strokeStyle = isLight ? 'rgba(255,255,255,0.22)' : 'rgba(0,0,0,0.14)';
        ctx.lineWidth = Math.max(1, size * 0.08);
        ctx.globalAlpha = opacity * 0.45;
        ctx.beginPath();
        ctx.moveTo(p1.x + perpX * offset, p1.y + perpY * offset);
        ctx.lineTo(p2.x + perpX * offset, p2.y + perpY * offset);
        ctx.stroke();
      }
    } else if (toolType === 'pencil') {
      // 4. Colored Pencil: Waxy grainy tooth across cold-press paper
      const dist = Math.hypot(p2.x - p1.x, p2.y - p1.y);
      const steps = Math.max(1, Math.ceil(dist / 2));
      const radius = size * 0.5;

      ctx.fillStyle = color;
      for (let s = 0; s <= steps; s++) {
        const t = s / steps;
        const cx = p1.x + (p2.x - p1.x) * t;
        const cy = p1.y + (p2.y - p1.y) * t;

        const particleCount = Math.max(4, Math.floor(size * 1.3));
        for (let k = 0; k < particleCount; k++) {
          const r = Math.pow(Math.random(), 1.5) * radius;
          const theta = Math.random() * Math.PI * 2;
          const px = cx + Math.cos(theta) * r;
          const py = cy + Math.sin(theta) * r;
          const grainAlpha = (1 - (r / radius) * 0.55) * opacity * (0.18 + Math.random() * 0.4);

          ctx.globalAlpha = Math.min(1.0, grainAlpha);
          const dotSize = 0.8 + Math.random() * 1.5;
          ctx.fillRect(px, py, dotSize, dotSize);
        }
      }
    } else if (toolType === 'pastel') {
      // 5. Oil Pastel: Creamy, powdery wax clumping along rough paper edges
      const dist = Math.hypot(p2.x - p1.x, p2.y - p1.y);
      const steps = Math.max(1, Math.ceil(dist / 3));
      const radius = size * 0.5;

      ctx.fillStyle = color;
      ctx.strokeStyle = color;

      // Soft core stroke
      ctx.lineWidth = size * 0.75;
      ctx.lineCap = 'round';
      ctx.globalAlpha = opacity * 0.75;
      ctx.beginPath();
      ctx.moveTo(p1.x, p1.y);
      ctx.lineTo(p2.x, p2.y);
      ctx.stroke();

      // Creamy textured pigment dabs
      for (let s = 0; s <= steps; s++) {
        const t = s / steps;
        const cx = p1.x + (p2.x - p1.x) * t;
        const cy = p1.y + (p2.y - p1.y) * t;

        const clumps = Math.max(2, Math.floor(size * 0.4));
        for (let k = 0; k < clumps; k++) {
          const r = (0.2 + Math.random() * 0.8) * radius;
          const theta = Math.random() * Math.PI * 2;
          const px = cx + Math.cos(theta) * r;
          const py = cy + Math.sin(theta) * r;
          const dabSize = 1.6 + Math.random() * 2.6;

          ctx.globalAlpha = opacity * (0.3 + Math.random() * 0.35);
          ctx.beginPath();
          ctx.arc(px, py, dabSize, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    } else if (toolType === 'marker') {
      // 6. Alcohol Marker: Translucent angled chisel ribbon
      ctx.lineCap = 'square';
      ctx.lineJoin = 'miter';
      ctx.fillStyle = color;
      ctx.strokeStyle = color;
      ctx.globalAlpha = opacity * 0.42;

      // 45 degree chisel slant
      const angle = Math.PI / 4;
      const dx = Math.cos(angle) * (size * 0.5);
      const dy = Math.sin(angle) * (size * 0.5);

      ctx.beginPath();
      ctx.moveTo(p1.x - dx, p1.y - dy);
      ctx.lineTo(p1.x + dx, p1.y + dy);
      ctx.lineTo(p2.x + dx, p2.y + dy);
      ctx.lineTo(p2.x - dx, p2.y - dy);
      ctx.closePath();
      ctx.fill();
    } else if (toolType === 'airbrush') {
      // 7. Airbrush: Soft feathered radial gradient mist
      const dist = Math.hypot(p2.x - p1.x, p2.y - p1.y);
      const steps = Math.max(1, Math.ceil(dist / 4));
      const radius = size * 0.8;

      for (let s = 0; s <= steps; s++) {
        const t = s / steps;
        const cx = p1.x + (p2.x - p1.x) * t;
        const cy = p1.y + (p2.y - p1.y) * t;

        const grad = ctx.createRadialGradient(cx, cy, 0, cx, cy, radius);
        grad.addColorStop(0, color);
        grad.addColorStop(0.35, color);
        grad.addColorStop(1, 'transparent');

        ctx.fillStyle = grad;
        ctx.globalAlpha = opacity * 0.14;
        ctx.beginPath();
        ctx.arc(cx, cy, radius, 0, Math.PI * 2);
        ctx.fill();
      }
    } else if (toolType === 'pen') {
      // 8. Fine Pen: Sharp crisp ink contour & hatching line
      ctx.strokeStyle = color;
      ctx.lineWidth = Math.max(1, size * 0.12);
      ctx.globalAlpha = 0.95;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';

      ctx.beginPath();
      ctx.moveTo(p1.x, p1.y);
      ctx.lineTo(p2.x, p2.y);
      ctx.stroke();
    } else if (toolType === 'blender') {
      // 9. Blender / Tortillon (찰필): Softly smudges and blurs adjacent pigments
      const paintCanvas = paintCanvasRef.current;
      if (paintCanvas) {
        const sampleCtx = paintCanvas.getContext('2d', { willReadFrequently: true });
        if (sampleCtx) {
          const sample = sampleCtx.getImageData(Math.floor(p1.x), Math.floor(p1.y), 1, 1).data;
          if (sample[3] > 10) {
            const blendColor = `rgba(${sample[0]}, ${sample[1]}, ${sample[2]}, ${opacity * 0.28})`;
            ctx.strokeStyle = blendColor;
            ctx.fillStyle = blendColor;
            ctx.lineWidth = size * 1.25;
            ctx.lineCap = 'round';
            ctx.shadowColor = blendColor;
            ctx.shadowBlur = size * 0.55;
            ctx.beginPath();
            ctx.moveTo(p1.x, p1.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.stroke();
          }
        }
      }
    }

    ctx.restore();
  };

  const drawSegment = (p1: { x: number; y: number }, p2: { x: number; y: number }) => {
    const canvas = paintCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    renderBrushSegment(ctx, tool, p1, p2, selectedColor, brushSize, brushOpacity);
  };

  // Drawing Handlers
  const handleStartDraw = (e: React.MouseEvent<HTMLDivElement> | React.TouchEvent<HTMLDivElement>) => {
    if (isPanning) return;
    const { x, y } = getCanvasCoords(e);

    if (tool === 'fill') {
      // Tap fill (Soft area flood)
      floodFillArea(Math.round(x), Math.round(y), selectedColor);
      sound.playWaterBrush(0.09);
      return;
    }

    isDrawing.current = true;
    currentPoints.current = [{ x, y }];

    playBrushAudio(tool, true);
    drawSegment({ x, y }, { x, y });
  };

  const handleMoveDraw = (e: React.MouseEvent<HTMLDivElement> | React.TouchEvent<HTMLDivElement>) => {
    if (!isDrawing.current || isPanning) return;
    const coords = getCanvasCoords(e);
    const pts = currentPoints.current;
    const prev = pts[pts.length - 1];

    if (prev) {
      const dist = Math.hypot(coords.x - prev.x, coords.y - prev.y);
      if (dist >= 2) {
        pts.push(coords);
        drawSegment(prev, coords);

        // Sound ASMR sampling
        if (Math.random() < 0.28) {
          playBrushAudio(tool, false);
        }
      }
    }
  };

  const handleEndDraw = () => {
    if (isDrawing.current) {
      isDrawing.current = false;
      if (currentPoints.current.length > 0) {
        strokesRef.current.push({
          type: tool,
          color: selectedColor,
          size: brushSize,
          opacity: brushOpacity,
          points: [...currentPoints.current]
        });
        currentPoints.current = [];
        saveStateToHistory();
      }
    }
  };

  // Smart Tap Fill (Fast flood fill inside bounds)
  const floodFillArea = (startX: number, startY: number, fillColor: string) => {
    const canvas = paintCanvasRef.current;
    const outlineCanvas = outlineCanvasRef.current;
    if (!canvas || !outlineCanvas) return;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    const outlineCtx = outlineCanvas.getContext('2d', { willReadFrequently: true });
    if (!ctx || !outlineCtx) return;

    const w = canvas.width;
    const h = canvas.height;

    // Convert hex fillColor to rgba
    const tempDiv = document.createElement('div');
    tempDiv.style.color = fillColor;
    document.body.appendChild(tempDiv);
    const rgbStr = window.getComputedStyle(tempDiv).color;
    document.body.removeChild(tempDiv);
    const match = rgbStr.match(/\d+/g);
    if (!match) return;

    const fillR = parseInt(match[0]);
    const fillG = parseInt(match[1]);
    const fillB = parseInt(match[2]);
    const fillA = Math.round(brushOpacity * 255);

    const imgData = ctx.getImageData(0, 0, w, h);
    const outlineData = outlineCtx.getImageData(0, 0, w, h);
    const pixels = imgData.data;
    const outlinePixels = outlineData.data;

    const targetIdx = (startY * w + startX) * 4;
    const startR = pixels[targetIdx];
    const startG = pixels[targetIdx + 1];
    const startB = pixels[targetIdx + 2];

    // Don't fill if clicking an outline
    if (outlinePixels[targetIdx + 3] > 180) return;
    if (Math.abs(startR - fillR) < 15 && Math.abs(startG - fillG) < 15 && Math.abs(startB - fillB) < 15) return;

    const queue: Array<[number, number]> = [[startX, startY]];
    const visited = new Uint8Array(w * h);

    const tolerance = 40;
    const matchStart = (idx: number) => {
      // Block if hit dark outline
      if (outlinePixels[idx + 3] > 150 && (outlinePixels[idx] < 80 || outlinePixels[idx + 1] < 80)) return false;
      const dr = Math.abs(pixels[idx] - startR);
      const dg = Math.abs(pixels[idx + 1] - startG);
      const db = Math.abs(pixels[idx + 2] - startB);
      return dr + dg + db <= tolerance * 3;
    };

    let count = 0;
    const maxPixels = w * h;

    while (queue.length > 0 && count < maxPixels) {
      const [cx, cy] = queue.pop()!;
      const idx = (cy * w + cx) * 4;
      const pos = cy * w + cx;

      if (visited[pos]) continue;
      visited[pos] = 1;
      count++;

      // Blend color
      pixels[idx] = fillR;
      pixels[idx + 1] = fillG;
      pixels[idx + 2] = fillB;
      pixels[idx + 3] = fillA;

      if (cx > 0 && !visited[pos - 1] && matchStart(idx - 4)) queue.push([cx - 1, cy]);
      if (cx < w - 1 && !visited[pos + 1] && matchStart(idx + 4)) queue.push([cx + 1, cy]);
      if (cy > 0 && !visited[pos - w] && matchStart(idx - w * 4)) queue.push([cx, cy - 1]);
      if (cy < h - 1 && !visited[pos + w] && matchStart(idx + w * 4)) queue.push([cx, cy + 1]);
    }

    ctx.putImageData(imgData, 0, 0);
    saveStateToHistory();
  };

  // Replay user's coloring strokes as a fast speedpainting with faithful brush rendering
  const handleReplayMyPainting = async () => {
    if (strokesRef.current.length === 0) return;
    setIsReplaying(true);

    const canvas = paintCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, artwork.width, artwork.height);
    ctx.fillStyle = '#FAF7F2';
    ctx.fillRect(0, 0, artwork.width, artwork.height);

    const strokes = [...strokesRef.current];
    const total = strokes.length;

    for (let i = 0; i < total; i++) {
      const s = strokes[i];
      for (let j = 1; j < s.points.length; j++) {
        renderBrushSegment(ctx, s.type, s.points[j - 1], s.points[j], s.color, s.size, s.opacity);
      }
      if (i % 2 === 0) {
        playBrushAudio(s.type, false);
        await new Promise((r) => setTimeout(r, 16));
      }
    }

    sound.playZenChime(523.25, 2.5, 0.08);
    setIsReplaying(false);
  };

  // Download high-res merged artwork (Toss & Web compatible)
  const handleDownload = async () => {
    const paint = paintCanvasRef.current;
    const outline = outlineCanvasRef.current;
    if (!paint || !outline) return;

    const merged = document.createElement('canvas');
    merged.width = artwork.width;
    merged.height = artwork.height;
    const ctx = merged.getContext('2d');
    if (!ctx) return;

    // Draw paint layer, then line layer
    ctx.drawImage(paint, 0, 0);
    ctx.drawImage(outline, 0, 0);

    const dataUrl = merged.toDataURL('image/png');
    await saveArtworkImage(dataUrl, `${artwork.title}-힐링컬러링.png`);
    sound.playZenChime(587.33, 2.0, 0.06);
  };

  // Save to Gallery
  const handleSaveToGallery = () => {
    const paint = paintCanvasRef.current;
    const outline = outlineCanvasRef.current;
    if (!paint || !outline) return;

    const merged = document.createElement('canvas');
    merged.width = artwork.width;
    merged.height = artwork.height;
    const ctx = merged.getContext('2d');
    if (!ctx) return;

    ctx.drawImage(paint, 0, 0);
    ctx.drawImage(outline, 0, 0);

    // Downsample thumbnail to 600px width for crisp quality and balanced localStorage size
    const thumbCanvas = document.createElement('canvas');
    const scale = Math.min(1, 600 / merged.width);
    thumbCanvas.width = Math.round(merged.width * scale);
    thumbCanvas.height = Math.round(merged.height * scale);
    const thumbCtx = thumbCanvas.getContext('2d');
    if (thumbCtx) {
      thumbCtx.drawImage(merged, 0, 0, thumbCanvas.width, thumbCanvas.height);
    }
    const thumb = thumbCanvas.toDataURL('image/jpeg', 0.82);

    const paintingRecord: SavedPainting = {
      id: `saved-${Date.now()}`,
      artworkId: artwork.id,
      title: artwork.title,
      category: artwork.category,
      thumbnail: thumb,
      completedAt: new Date().toLocaleDateString('ko-KR')
    };

    const saveResult = onSaveToGallery(paintingRecord);
    if (saveResult === false) {
      setSaveErrorMessage('저장 공간이 가득 찼어요. 스케치북에서 오래된 작품을 정리해 주세요.');
      setTimeout(() => setSaveErrorMessage(null), 5000);
    } else {
      setSavedNotification(true);
      sound.playZenChime(523.25, 2.5, 0.08);
      setTimeout(() => setSavedNotification(false), 2800);
    }
  };

  // Filtered tools according to active tab
  const displayedTools = TOOL_DEFINITIONS.filter(
    (t) => toolCategoryTab === 'all' || t.category === toolCategoryTab
  );

  // Helper icon renderer
  const renderToolIcon = (toolId: ToolMode, className: string = 'w-4 h-4') => {
    switch (toolId) {
      case 'watercolor':
        return <Droplet className={`${className} text-sky-500`} />;
      case 'oil':
        return <Paintbrush className={`${className} text-amber-600`} />;
      case 'acrylic':
        return <Layers className={`${className} text-indigo-600`} />;
      case 'pencil':
        return <Pencil className={`${className} text-orange-600`} />;
      case 'pastel':
        return <Sparkles className={`${className} text-rose-500`} />;
      case 'marker':
        return <Highlighter className={`${className} text-teal-600`} />;
      case 'airbrush':
        return <Wind className={`${className} text-violet-500`} />;
      case 'pen':
        return <PenTool className={`${className} text-stone-800`} />;
      case 'blender':
        return <Blend className={`${className} text-purple-600`} />;
      case 'fill':
        return <PaintBucket className={`${className} text-emerald-600`} />;
      case 'eraser':
        return <Eraser className={`${className} text-rose-500`} />;
      default:
        return <Paintbrush className={className} />;
    }
  };

  return (
    <div className="w-full flex flex-col items-center">
      {/* Top Studio Bar */}
      <div className="w-full max-w-6xl px-3 sm:px-4 mb-3 flex flex-wrap items-center justify-between gap-2.5 sm:gap-3 border-b border-stone-200/80 pb-3">
        <div className="flex items-center gap-2 sm:gap-3 min-w-0">
          <button
            onClick={onBackToTimelapse}
            className="text-xs text-stone-500 hover:text-stone-900 transition-colors flex items-center gap-1 whitespace-nowrap cursor-pointer shrink-0"
          >
            ← <span className="hidden sm:inline">멍때리기</span> 감상으로
          </button>
          <span className="text-stone-300">|</span>
          <h2 className="font-serif text-base sm:text-xl md:text-2xl font-medium text-stone-900 truncate">
            {artwork.title}
          </h2>
        </div>

        {/* Action buttons (Undo, Redo, Replay, Save, Download) with whitespace-nowrap */}
        <div className="flex items-center gap-1 sm:gap-2 shrink-0">
          <button
            onClick={handleUndo}
            disabled={historyIndex <= 0}
            className="p-1.5 sm:p-2 text-stone-600 hover:text-stone-900 disabled:opacity-30 rounded-lg hover:bg-stone-200/50 transition-colors cursor-pointer"
            title="실행 취소 (Undo)"
          >
            <Undo className="w-4 h-4" />
          </button>
          <button
            onClick={handleRedo}
            disabled={historyIndex >= history.length - 1}
            className="p-1.5 sm:p-2 text-stone-600 hover:text-stone-900 disabled:opacity-30 rounded-lg hover:bg-stone-200/50 transition-colors cursor-pointer"
            title="다시 실행 (Redo)"
          >
            <Redo className="w-4 h-4" />
          </button>

          <span className="text-stone-300">|</span>

          {/* Replay My Painting */}
          <button
            onClick={handleReplayMyPainting}
            disabled={isReplaying || strokesRef.current.length === 0}
            className="flex items-center gap-1 px-2 sm:px-2.5 py-1.5 text-xs text-stone-700 bg-white hover:bg-stone-50 border border-stone-200/80 rounded-lg shadow-2xs transition-colors disabled:opacity-40 whitespace-nowrap cursor-pointer"
            title="내가 칠한 과정 스피드페인팅으로 다시보기"
          >
            <Play className="w-3.5 h-3.5 text-amber-700 fill-current" />
            <span className="hidden sm:inline whitespace-nowrap">재생</span>
          </button>

          {/* Save to Gallery */}
          <button
            onClick={handleSaveToGallery}
            className="flex items-center gap-1 px-2.5 sm:px-3 py-1.5 text-xs font-medium text-stone-800 bg-stone-100 hover:bg-stone-200 border border-stone-300/70 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
          >
            <Save className="w-3.5 h-3.5 shrink-0" />
            <span className="whitespace-nowrap">보관함 저장</span>
          </button>

          {/* Download PNG */}
          <button
            onClick={handleDownload}
            className="flex items-center gap-1 px-2.5 sm:px-3 py-1.5 text-xs font-semibold text-white bg-stone-900 hover:bg-stone-800 rounded-lg shadow-xs transition-colors whitespace-nowrap cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 shrink-0" />
            <span className="whitespace-nowrap">완성본 다운로드</span>
          </button>
        </div>
      </div>

      {/* Studio Workspace: Canvas (Order 1 on mobile) + Tool Settings (Order 2 on mobile) */}
      <div className="w-full max-w-6xl px-2 sm:px-4 flex flex-col lg:flex-row gap-4 sm:gap-5 items-start">
        {/* Canvas Workspace: Order 1 on mobile so it is instantly visible at top! */}
        <div
          ref={containerRef}
          className="order-1 lg:order-2 flex-1 w-full max-w-full flex flex-col justify-center items-center overflow-hidden rounded-2xl canvas-paper-shadow border border-stone-300/60 bg-[#FAF7F2] p-2 sm:p-4 min-h-[260px] sm:min-h-[460px] lg:min-h-[560px] relative shrink-0"
        >
          {/* Canvas Wrapper with Zoom/Pan */}
          <div
            className="relative select-none touch-none cursor-crosshair transition-transform duration-75 w-full max-w-full flex items-center justify-center"
            style={{
              transform: `scale(${zoom}) translate(${pan.x}px, ${pan.y}px)`,
              transformOrigin: 'center center'
            }}
            onMouseDown={handleStartDraw}
            onMouseMove={handleMoveDraw}
            onMouseUp={handleEndDraw}
            onMouseLeave={handleEndDraw}
            onTouchStart={handleStartDraw}
            onTouchMove={handleMoveDraw}
            onTouchEnd={handleEndDraw}
          >
            <div
              className="relative w-full max-w-full flex items-center justify-center"
              style={{ maxWidth: `${artwork.width}px` }}
            >
              {/* Layer 1: Under-painting Color Canvas */}
              <canvas
                ref={paintCanvasRef}
                width={artwork.width}
                height={artwork.height}
                className="block w-full max-w-full h-auto max-h-[50vh] sm:max-h-[68vh] object-contain rounded-lg"
                style={{ aspectRatio: `${artwork.width} / ${artwork.height}` }}
              />

              {/* Layer 2: Pen Outline Canvas overlaid on top so outlines are never erased */}
              <canvas
                ref={outlineCanvasRef}
                width={artwork.width}
                height={artwork.height}
                className="absolute inset-0 pointer-events-none block w-full max-w-full h-auto max-h-[50vh] sm:max-h-[68vh] object-contain rounded-lg"
                style={{ aspectRatio: `${artwork.width} / ${artwork.height}` }}
              />
            </div>
          </div>

          {/* Replay Overlay */}
          {isReplaying && (
            <div className="absolute top-3 left-3 z-30 bg-black/75 backdrop-blur-xs text-white px-2.5 py-1 rounded-full text-xs flex items-center gap-1.5 shadow-lg">
              <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
              <span>타임랩스 재생 중...</span>
            </div>
          )}

          {/* Under Canvas Quick Guidance & Zoom/Reset Controls */}
          <div className="w-full max-w-xl mt-2 sm:mt-3 flex items-center justify-between text-2xs text-stone-500 px-1">
            <div className="flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-600 shrink-0" />
              <span className="truncate">윤곽선 보호 활성화</span>
            </div>
            <div className="flex items-center gap-1 shrink-0">
              <span className="text-stone-400 mr-1">{Math.round(zoom * 100)}%</span>
              <button
                onClick={() => setZoom((z) => Math.max(0.6, z - 0.2))}
                className="p-1 hover:bg-stone-200/60 rounded text-stone-600 cursor-pointer"
                title="축소"
              >
                <ZoomOut className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => {
                  setZoom(1.0);
                  setPan({ x: 0, y: 0 });
                }}
                className="p-1 hover:bg-stone-200/60 rounded text-stone-600 cursor-pointer"
                title="배율 초기화"
              >
                <Maximize2 className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => setZoom((z) => Math.min(2.5, z + 0.2))}
                className="p-1 hover:bg-stone-200/60 rounded text-stone-600 cursor-pointer"
                title="확대"
              >
                <ZoomIn className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Saved to Gallery Notification Toast */}
          {savedNotification && (
            <div className="absolute top-3 right-3 px-3 py-1.5 bg-stone-900/90 backdrop-blur-md text-white text-xs font-medium rounded-xl flex items-center gap-1.5 shadow-lg animate-in fade-in slide-in-from-top-2 duration-200 z-20">
              <Check className="w-4 h-4 text-emerald-400" />
              <span>보관함에 저장되었습니다!</span>
            </div>
          )}

          {/* Storage Full Warning Notification */}
          {saveErrorMessage && (
            <div className="absolute top-3 right-3 max-w-xs px-3 py-2 bg-rose-900/95 backdrop-blur-md text-white text-xs font-medium rounded-xl flex items-center gap-2 shadow-xl animate-in fade-in slide-in-from-top-2 duration-200 border border-rose-700/50 z-20">
              <AlertCircle className="w-4 h-4 text-rose-300 shrink-0" />
              <span>{saveErrorMessage}</span>
            </div>
          )}
        </div>

        {/* Tools & Palette Panel: Order 2 on mobile (placed directly below canvas) */}
        <div className="order-2 lg:order-1 w-full lg:w-84 bg-white/90 backdrop-blur-xs border border-stone-200/80 rounded-2xl p-3.5 sm:p-4 space-y-3.5 sm:space-y-4 shadow-2xs shrink-0">
          {/* Section 1: Curated 1-Row Artwork Recommended Palette + Custom Picker (Top priority for quick coloring) */}
          <div className="p-2.5 bg-stone-50/80 rounded-xl border border-stone-200/60">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-stone-700 flex items-center gap-1">
                <span>작품 추천 팔레트</span>
                <span
                  className="w-3.5 h-3.5 rounded-full border border-stone-300 inline-block shadow-2xs ml-1"
                  style={{ backgroundColor: selectedColor }}
                />
              </span>
              <div className="flex items-center gap-1.5">
                <span className="text-[11px] text-stone-500 font-mono">{selectedColor.toUpperCase()}</span>
                <input
                  type="color"
                  value={selectedColor}
                  onChange={(e) => setSelectedColor(e.target.value)}
                  className="w-5 h-5 cursor-pointer rounded border-0 p-0 bg-transparent"
                  title="직접 색상 선택"
                />
              </div>
            </div>
            {/* 1 Row Swatches */}
            <div className="flex items-center gap-2 overflow-x-auto scrollbar-none py-0.5">
              {artwork.palette.map((c, cIdx) => (
                <button
                  key={cIdx}
                  onClick={() => setSelectedColor(c)}
                  className={`w-7 h-7 rounded-full border shrink-0 transition-transform cursor-pointer ${
                    selectedColor.toLowerCase() === c.toLowerCase()
                      ? 'scale-115 border-stone-900 shadow-xs ring-2 ring-stone-900/20'
                      : 'border-black/15 hover:scale-105'
                  }`}
                  style={{ backgroundColor: c }}
                  title={c}
                />
              ))}
            </div>
          </div>

          {/* Section 2: Brush Tool Tray & Filter Tabs */}
          <div>
            <div className="flex items-center justify-between gap-1.5 mb-2">
              <label className="text-xs font-semibold text-stone-600 uppercase tracking-wider flex items-center gap-1 shrink-0">
                <span>도구함</span>
                <span className="text-2xs px-1.5 py-0.5 rounded-full bg-amber-100 text-amber-800 font-medium">
                  {TOOL_DEFINITIONS.length}종
                </span>
              </label>

              {/* Category Filter Pills with whitespace-nowrap and horizontal scrollability */}
              <div className="flex items-center gap-1 text-2xs overflow-x-auto scrollbar-none py-0.5 pl-1 shrink min-w-0">
                {(['all', '회화', '드로잉', '스튜디오'] as const).map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setToolCategoryTab(cat)}
                    className={`px-2 py-0.5 rounded-md transition-colors whitespace-nowrap cursor-pointer shrink-0 ${
                      toolCategoryTab === cat
                        ? 'bg-stone-800 text-white font-medium'
                        : 'text-stone-500 hover:text-stone-800 hover:bg-stone-100'
                    }`}
                  >
                    {cat === 'all' ? '전체' : cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Brush Tool Tray */}
            <div className="p-1 bg-stone-100/90 rounded-xl space-y-1">
              {toolCategoryTab === 'all' ? (
                <>
                  {/* Row 1: 6 Painting & Drawing Media */}
                  <div className="grid grid-cols-6 gap-1">
                    {displayedTools.slice(0, 6).map((tDef) => {
                      const isSelected = tool === tDef.id;
                      return (
                        <button
                          key={tDef.id}
                          onClick={() => handleSelectTool(tDef.id)}
                          className={`flex flex-col items-center justify-center py-2 px-0.5 rounded-lg text-center transition-all cursor-pointer ${
                            isSelected
                              ? 'bg-white text-stone-900 shadow-xs ring-2 ring-stone-900/15 font-semibold scale-[1.03]'
                              : 'bg-stone-50/60 hover:bg-white/80 text-stone-600 hover:text-stone-900'
                          }`}
                          title={`${tDef.name} - ${tDef.desc}`}
                        >
                          <div className="mb-0.5">{renderToolIcon(tDef.id, 'w-4 h-4')}</div>
                          <span className="text-[11px] leading-none font-medium truncate max-w-full whitespace-nowrap">
                            {tDef.name}
                          </span>
                        </button>
                      );
                    })}
                  </div>

                  {/* Row 2: 5 Finish, Spatter & Studio Tools */}
                  <div className="grid grid-cols-5 gap-1">
                    {displayedTools.slice(6).map((tDef) => {
                      const isSelected = tool === tDef.id;
                      return (
                        <button
                          key={tDef.id}
                          onClick={() => handleSelectTool(tDef.id)}
                          className={`flex flex-col items-center justify-center py-2 px-0.5 rounded-lg text-center transition-all cursor-pointer ${
                            isSelected
                              ? 'bg-white text-stone-900 shadow-xs ring-2 ring-stone-900/15 font-semibold scale-[1.03]'
                              : 'bg-stone-50/60 hover:bg-white/80 text-stone-600 hover:text-stone-900'
                          }`}
                          title={`${tDef.name} - ${tDef.desc}`}
                        >
                          <div className="mb-0.5">{renderToolIcon(tDef.id, 'w-4 h-4')}</div>
                          <span className="text-[11px] leading-none font-medium truncate max-w-full whitespace-nowrap">
                            {tDef.name}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </>
              ) : (
                /* Filtered view: Clean single row */
                <div
                  className={`grid gap-1 ${
                    displayedTools.length === 4
                      ? 'grid-cols-4'
                      : displayedTools.length === 3
                      ? 'grid-cols-3'
                      : 'grid-cols-5'
                  }`}
                >
                  {displayedTools.map((tDef) => {
                    const isSelected = tool === tDef.id;
                    return (
                      <button
                        key={tDef.id}
                        onClick={() => handleSelectTool(tDef.id)}
                        className={`flex flex-col items-center justify-center py-2 px-1 rounded-lg text-center transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-white text-stone-900 shadow-xs ring-2 ring-stone-900/15 font-semibold scale-[1.02]'
                            : 'bg-stone-50/70 hover:bg-white/80 text-stone-600 hover:text-stone-900'
                        }`}
                        title={`${tDef.name} - ${tDef.desc}`}
                      >
                        <div className="mb-0.5">{renderToolIcon(tDef.id, 'w-4 h-4')}</div>
                        <span className="text-xs leading-none font-medium truncate whitespace-nowrap">
                          {tDef.name}
                        </span>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          </div>

          {/* Section 3: Sliders: Dynamic Size & Dynamic Opacity / Pressure */}
          <div className="space-y-3 pt-1 border-t border-stone-100">
            <div>
              <div className="flex justify-between text-xs text-stone-600 mb-1">
                <span>{activeToolDef.sizeLabel}</span>
                <span className="font-mono text-stone-500">{brushSize}px</span>
              </div>
              <input
                type="range"
                min="4"
                max="68"
                value={brushSize}
                onChange={(e) => setBrushSize(parseInt(e.target.value))}
                className="w-full h-1.5 bg-stone-200 rounded-lg appearance-none cursor-pointer accent-stone-800"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs text-stone-600 mb-1">
                <span>{activeToolDef.opacityLabel}</span>
                <span className="font-mono text-stone-500">{Math.round(brushOpacity * 100)}%</span>
              </div>
              <input
                type="range"
                min="0.1"
                max="1.0"
                step="0.05"
                value={brushOpacity}
                onChange={(e) => setBrushOpacity(parseFloat(e.target.value))}
                className="w-full h-1.5 bg-stone-200 rounded-lg appearance-none cursor-pointer accent-stone-800"
              />
            </div>
          </div>

          {/* Section 4: Active Tool Description & Artist Tip Card */}
          <div className="bg-amber-50/70 border border-amber-200/60 rounded-xl p-2.5 text-xs text-stone-700 space-y-1">
            <div className="flex items-center justify-between font-medium text-amber-950">
              <div className="flex items-center gap-1.5">
                {renderToolIcon(activeToolDef.id, 'w-3.5 h-3.5')}
                <span className="font-semibold whitespace-nowrap">{activeToolDef.name}</span>
                <span className="text-2xs text-amber-700 bg-amber-100/80 px-1.5 py-0.2 rounded whitespace-nowrap">
                  {activeToolDef.desc}
                </span>
              </div>
            </div>
            <p className="text-2xs text-stone-600 leading-relaxed pl-5">
              💡 {activeToolDef.artTip}
            </p>
          </div>

          {/* Section 5: Additional Curated Color Palettes */}
          <div className="space-y-2 pt-1 border-t border-stone-100">
            <label className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
              테마별 추가 팔레트
            </label>
            <div className="space-y-2 max-h-36 overflow-y-auto pr-1">
              {curatedPalettes.slice(1).map((palette, pIdx) => (
                <div key={pIdx} className="bg-stone-50/70 p-2 rounded-xl border border-stone-200/50">
                  <div className="text-2xs text-stone-500 mb-1.5 font-medium">{palette.name}</div>
                  <div className="flex flex-wrap gap-1.5">
                    {palette.colors.map((c, cIdx) => (
                      <button
                        key={cIdx}
                        onClick={() => setSelectedColor(c)}
                        className={`w-6 h-6 rounded-full border transition-transform cursor-pointer ${
                          selectedColor.toLowerCase() === c.toLowerCase()
                            ? 'scale-115 border-stone-900 shadow-xs ring-2 ring-stone-900/20'
                            : 'border-black/10 hover:scale-105'
                        }`}
                        style={{ backgroundColor: c }}
                        title={c}
                      />
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
