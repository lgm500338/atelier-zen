import React from 'react';
import { Download, Trash2, Palette, Eye, BookOpen } from 'lucide-react';
import { SavedPainting, Artwork } from '../types/artwork';
import { saveArtworkImage } from '../utils/tossBridge';

interface MySketchbookProps {
  savedList: SavedPainting[];
  artworks: Artwork[];
  onOpenArtwork: (artwork: Artwork, mode: 'timelapse' | 'coloring') => void;
  onDeleteSaved: (id: string) => void;
}

export const MySketchbook: React.FC<MySketchbookProps> = ({
  savedList,
  artworks,
  onOpenArtwork,
  onDeleteSaved
}) => {
  const handleDownload = async (item: SavedPainting) => {
    await saveArtworkImage(item.thumbnail, `${item.title}-완성작.jpg`);
  };

  const findArtwork = (artworkId: string) => {
    return artworks.find((a) => a.id === artworkId);
  };

  return (
    <div className="w-full max-w-7xl mx-auto px-4 md:px-8 py-6 space-y-6">
      <div className="border-b border-stone-200/80 pb-4">
        <div className="text-xs tracking-wider uppercase text-stone-500 font-sans mb-1">
          PERSONAL ATELIER · ARCHIVE
        </div>
        <h1 className="font-serif text-3xl font-medium text-stone-900 tracking-tight">
          내 스케치북 & 완성작 보관함
        </h1>
        <p className="text-xs sm:text-sm text-stone-600 mt-1">
          정성껏 완성한 나만의 컬러링 작품들을 모아보고 고화질로 간직하세요.
        </p>
      </div>

      {savedList.length === 0 ? (
        <div className="py-20 text-center bg-white/70 rounded-2xl border border-stone-200/80 p-8 space-y-3">
          <div className="w-12 h-12 mx-auto rounded-full bg-stone-100 flex items-center justify-center text-stone-500">
            <BookOpen className="w-6 h-6" />
          </div>
          <h3 className="font-serif text-lg text-stone-800 font-medium">
            아직 보관된 완성작이 없습니다
          </h3>
          <p className="text-xs text-stone-500 max-w-sm mx-auto">
            도안을 골라 컬러링 스튜디오에서 색칠한 후 [보관함 저장]을 눌러 나만의 미술관을 채워보세요.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {savedList.map((item) => {
            const rawArtwork = findArtwork(item.artworkId);

            return (
              <div
                key={item.id}
                className="bg-[#FAF8F5] rounded-2xl overflow-hidden border border-stone-200/80 hover:border-stone-400/80 transition-all duration-300 canvas-paper-shadow flex flex-col justify-between"
              >
                <div className="relative aspect-4/3 bg-[#F4F1EA] overflow-hidden flex items-center justify-center p-3 border-b border-stone-200/60">
                  <img
                    src={item.thumbnail}
                    alt={item.title}
                    className="w-full h-full object-contain rounded-lg"
                  />
                  <div className="absolute bottom-2 right-2 text-2xs text-stone-400 bg-black/60 backdrop-blur-xs px-2 py-0.5 rounded text-white font-mono">
                    {item.completedAt}
                  </div>
                </div>

                <div className="p-4 space-y-2">
                  <h3 className="font-serif text-lg font-medium text-stone-900 leading-snug">
                    {item.title}
                  </h3>

                  <div className="flex items-center justify-between pt-3 border-t border-stone-200/60">
                    <button
                      onClick={() => handleDownload(item)}
                      className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-stone-700 hover:text-stone-900 bg-white hover:bg-stone-50 border border-stone-200 rounded-lg shadow-2xs transition-colors"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>다운로드</span>
                    </button>

                    <div className="flex items-center gap-1">
                      {rawArtwork && (
                        <button
                          onClick={() => onOpenArtwork(rawArtwork, 'coloring')}
                          className="p-1.5 text-stone-600 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg transition-colors"
                          title="다시 칠하기"
                        >
                          <Palette className="w-4 h-4 text-emerald-700" />
                        </button>
                      )}

                      <button
                        onClick={() => onDeleteSaved(item.id)}
                        className="p-1.5 text-stone-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                        title="보관함에서 삭제"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
