export type ArtCategory = 'urban' | 'oil' | 'pop' | 'botanical' | 'user';
export type ArtDifficulty = 'easy' | 'medium' | 'hard';

export interface DrawPath {
  type: 'stroke' | 'fill' | 'wash' | 'stipple';
  color: string;
  lineWidth?: number;
  opacity?: number;
  d: string; // SVG path data or command sequence
  label?: string;
}

export interface DrawingLayer {
  id: string;
  name: string; // e.g. '펜 스케치', '초벌 수채화 번짐', '잎사귀 명암 터치', '구름 & 하이라이트'
  style: 'pen' | 'watercolor' | 'oil' | 'highlight';
  paths: DrawPath[];
}

export interface Artwork {
  id: string;
  title: string;
  category: ArtCategory;
  categoryName: string;
  difficulty: ArtDifficulty;
  difficultyName: string;
  volume: string; // e.g. 'Vol. 1', 'Vol. 2', 'Vol. 3', '생성 도안'
  description: string;
  durationSeconds: number; // base duration at 1x
  width: number;
  height: number;
  palette: string[]; // Recommended soothing color palette
  layers: DrawingLayer[];
  isCustom?: boolean;
  sourceImage?: string; // For converted photo
  createdAt?: string;
}

export interface SavedPainting {
  id: string;
  artworkId: string;
  title: string;
  category: ArtCategory;
  thumbnail: string;
  completedAt: string;
  strokesHistory?: Array<{
    type: 'fill' | 'brush';
    color: string;
    pathPoints?: Array<[number, number]>;
    x?: number;
    y?: number;
    size?: number;
    opacity?: number;
  }>;
}
