// Pure Web Audio API Sound Generator for Calm ASMR & Ambient Chimes (No external files or network required)

class SoundEngine {
  private ctx: AudioContext | null = null;
  private isMuted: boolean = false;
  private ambientInterval: number | null = null;
  private noiseBuffer: AudioBuffer | null = null;

  private initContext() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
      this.createNoiseBuffer();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  private createNoiseBuffer() {
    if (!this.ctx) return;
    const bufferSize = this.ctx.sampleRate * 2; // 2 seconds of noise
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      // Pink-ish / brownian noise for realistic paper scratch
      data[i] = (Math.random() * 2 - 1) * 0.3;
    }
    this.noiseBuffer = buffer;
  }

  public setMuted(muted: boolean) {
    this.isMuted = muted;
    if (muted && this.ambientInterval) {
      window.clearInterval(this.ambientInterval);
      this.ambientInterval = null;
    }
  }

  public getMuted(): boolean {
    return this.isMuted;
  }

  // Realistic paper & pencil scratch sound for pen lines
  public playPencilScratch(volume = 0.08) {
    if (this.isMuted) return;
    try {
      this.initContext();
      if (!this.ctx || !this.noiseBuffer) return;

      const noise = this.ctx.createBufferSource();
      noise.buffer = this.noiseBuffer;

      // Bandpass filter to simulate pencil lead on textured paper
      const filter = this.ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(1400 + Math.random() * 800, this.ctx.currentTime);
      filter.Q.setValueAtTime(3.0, this.ctx.currentTime);

      const gain = this.ctx.createGain();
      const now = this.ctx.currentTime;
      const duration = 0.04 + Math.random() * 0.06;

      gain.gain.setValueAtTime(0.001, now);
      gain.gain.linearRampToValueAtTime(volume * (0.8 + Math.random() * 0.4), now + duration * 0.3);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

      noise.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);

      noise.start(now);
      noise.stop(now + duration);
    } catch {
      // Audio autoplay policy fallback
    }
  }

  // Soft watercolor brush dip / flow sound
  public playWaterBrush(volume = 0.09) {
    if (this.isMuted) return;
    try {
      this.initContext();
      if (!this.ctx || !this.noiseBuffer) return;

      const noise = this.ctx.createBufferSource();
      noise.buffer = this.noiseBuffer;

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(450, this.ctx.currentTime);
      filter.frequency.exponentialRampToValueAtTime(250, this.ctx.currentTime + 0.25);

      const gain = this.ctx.createGain();
      const now = this.ctx.currentTime;

      gain.gain.setValueAtTime(0.001, now);
      gain.gain.linearRampToValueAtTime(volume, now + 0.05);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.28);

      noise.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);

      noise.start(now);
      noise.stop(now + 0.3);
    } catch {
      // Ignore
    }
  }

  // Colored pencil textured scratch on grain paper
  public playColoredPencil(volume = 0.07) {
    if (this.isMuted) return;
    try {
      this.initContext();
      if (!this.ctx || !this.noiseBuffer) return;

      const noise = this.ctx.createBufferSource();
      noise.buffer = this.noiseBuffer;

      // Colored pencil has a distinct crunchy granular texture (two peaking filters)
      const filter = this.ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(2200 + Math.random() * 600, this.ctx.currentTime);
      filter.Q.setValueAtTime(4.5, this.ctx.currentTime);

      const gain = this.ctx.createGain();
      const now = this.ctx.currentTime;
      const duration = 0.035 + Math.random() * 0.04;

      gain.gain.setValueAtTime(0.001, now);
      gain.gain.linearRampToValueAtTime(volume * (0.85 + Math.random() * 0.3), now + duration * 0.2);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

      noise.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);

      noise.start(now);
      noise.stop(now + duration);
    } catch {
      // Ignore
    }
  }

  // Velvety soft friction for Oil Pastel / Chalk
  public playPastelChalk(volume = 0.06) {
    if (this.isMuted) return;
    try {
      this.initContext();
      if (!this.ctx || !this.noiseBuffer) return;

      const noise = this.ctx.createBufferSource();
      noise.buffer = this.noiseBuffer;

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(800 + Math.random() * 300, this.ctx.currentTime);

      const gain = this.ctx.createGain();
      const now = this.ctx.currentTime;
      const duration = 0.06 + Math.random() * 0.05;

      gain.gain.setValueAtTime(0.001, now);
      gain.gain.linearRampToValueAtTime(volume, now + duration * 0.3);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

      noise.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);

      noise.start(now);
      noise.stop(now + duration);
    } catch {
      // Ignore
    }
  }

  // Smooth felt-tip squeak / glide for alcohol marker
  public playMarker(volume = 0.06) {
    if (this.isMuted) return;
    try {
      this.initContext();
      if (!this.ctx || !this.noiseBuffer) return;

      const noise = this.ctx.createBufferSource();
      noise.buffer = this.noiseBuffer;

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(1100 + Math.random() * 200, this.ctx.currentTime);
      filter.Q.setValueAtTime(2.0, this.ctx.currentTime);

      const gain = this.ctx.createGain();
      const now = this.ctx.currentTime;
      const duration = 0.08 + Math.random() * 0.04;

      gain.gain.setValueAtTime(0.001, now);
      gain.gain.linearRampToValueAtTime(volume, now + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

      noise.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);

      noise.start(now);
      noise.stop(now + duration);
    } catch {
      // Ignore
    }
  }

  // Soft hiss / mist sound for airbrush spray
  public playAirbrush(volume = 0.05) {
    if (this.isMuted) return;
    try {
      this.initContext();
      if (!this.ctx || !this.noiseBuffer) return;

      const noise = this.ctx.createBufferSource();
      noise.buffer = this.noiseBuffer;

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'highpass';
      filter.frequency.setValueAtTime(3200, this.ctx.currentTime);

      const gain = this.ctx.createGain();
      const now = this.ctx.currentTime;
      const duration = 0.09;

      gain.gain.setValueAtTime(0.001, now);
      gain.gain.linearRampToValueAtTime(volume, now + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

      noise.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);

      noise.start(now);
      noise.stop(now + duration);
    } catch {
      // Ignore
    }
  }

  // Creamy thick acrylic brush stroke
  public playAcrylic(volume = 0.07) {
    if (this.isMuted) return;
    try {
      this.initContext();
      if (!this.ctx || !this.noiseBuffer) return;

      const noise = this.ctx.createBufferSource();
      noise.buffer = this.noiseBuffer;

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(650, this.ctx.currentTime);

      const gain = this.ctx.createGain();
      const now = this.ctx.currentTime;
      const duration = 0.07;

      gain.gain.setValueAtTime(0.001, now);
      gain.gain.linearRampToValueAtTime(volume, now + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

      noise.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);

      noise.start(now);
      noise.stop(now + duration);
    } catch {
      // Ignore
    }
  }

  // Paper blending stump / moist smudge
  public playBlender(volume = 0.05) {
    if (this.isMuted) return;
    try {
      this.initContext();
      if (!this.ctx || !this.noiseBuffer) return;

      const noise = this.ctx.createBufferSource();
      noise.buffer = this.noiseBuffer;

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(500, this.ctx.currentTime);
      filter.Q.setValueAtTime(1.5, this.ctx.currentTime);

      const gain = this.ctx.createGain();
      const now = this.ctx.currentTime;
      const duration = 0.08;

      gain.gain.setValueAtTime(0.001, now);
      gain.gain.linearRampToValueAtTime(volume, now + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

      noise.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);

      noise.start(now);
      noise.stop(now + duration);
    } catch {
      // Ignore
    }
  }

  // Gentle meditative singing bowl / chime for relaxation & completion
  public playZenChime(freq = 440, duration = 2.2, volume = 0.08) {
    if (this.isMuted) return;
    try {
      this.initContext();
      if (!this.ctx) return;

      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const osc2 = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now);

      // Subtle warm harmonic overtone
      osc2.type = 'triangle';
      osc2.frequency.setValueAtTime(freq * 1.5, now);

      gain.gain.setValueAtTime(0.001, now);
      gain.gain.linearRampToValueAtTime(volume, now + 0.08);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

      osc.connect(gain);
      osc2.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(now);
      osc2.start(now);
      osc.stop(now + duration);
      osc2.stop(now + duration);
    } catch {
      // Ignore
    }
  }

  // Start soothing ambient background chimes in pentatonic scale
  public toggleAmbientMusic(enabled: boolean) {
    if (!enabled || this.isMuted) {
      if (this.ambientInterval) {
        window.clearInterval(this.ambientInterval);
        this.ambientInterval = null;
      }
      return;
    }

    if (this.ambientInterval) return;

    // Pentatonic calm frequencies: D4, F#4, A4, B4, C#5, E5, F#5
    const notes = [293.66, 369.99, 440.0, 493.88, 554.37, 659.25, 739.99];

    this.ambientInterval = window.setInterval(() => {
      if (this.isMuted) return;
      const note = notes[Math.floor(Math.random() * notes.length)];
      this.playZenChime(note, 3.5, 0.035);
    }, 4500);

    // Initial chime
    this.playZenChime(notes[2], 3.0, 0.04);
  }
}

export const sound = new SoundEngine();
