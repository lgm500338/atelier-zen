import { Artwork, DrawingLayer, ArtCategory, ArtDifficulty } from '../types/artwork';

// Pure algorithmic procedural art generator (Zero API calls, limitless variations)
export function generateProceduralArtwork(
  theme: 'urban' | 'botanical' | 'oil' | 'pop',
  difficulty: ArtDifficulty = 'medium',
  seed: number = Date.now()
): Artwork {
  const rng = createSeededRng(seed);

  if (theme === 'urban') {
    return generateProceduralUrban(rng, difficulty);
  } else if (theme === 'botanical') {
    return generateProceduralBotanical(rng, difficulty);
  } else if (theme === 'oil') {
    return generateProceduralOil(rng, difficulty);
  } else {
    return generateProceduralPop(rng, difficulty);
  }
}

function createSeededRng(seed: number) {
  let s = seed % 2147483647;
  if (s <= 0) s += 2147483646;
  return function () {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

function generateProceduralUrban(rng: () => number, difficulty: ArtDifficulty): Artwork {
  const width = 700;
  const height = 800;
  const id = `procedural-urban-${Date.now()}-${Math.floor(rng() * 1000)}`;
  const houseX = 220 + Math.floor(rng() * 80);
  const houseY = 480 + Math.floor(rng() * 40);
  const houseW = 160 + Math.floor(rng() * 50);
  const houseH = 120 + Math.floor(rng() * 30);
  const roofHeight = 60 + Math.floor(rng() * 30);

  const roofColor = ['#C94A29', '#B85042', '#A23B2A', '#9B2226'][Math.floor(rng() * 4)];
  const skyColor = ['rgba(91, 133, 170, 0.4)', 'rgba(70, 140, 190, 0.45)', 'rgba(120, 160, 200, 0.4)'][Math.floor(rng() * 3)];
  const treeCount = difficulty === 'easy' ? 2 : difficulty === 'medium' ? 3 : 5;

  const sketchPaths: Array<{ type: 'stroke'; color: string; lineWidth: number; d: string }> = [];
  const washPaths: Array<{ type: 'wash'; color: string; lineWidth: number; d: string }> = [];
  const texturePaths: Array<{ type: 'wash' | 'stroke'; color: string; lineWidth: number; d: string }> = [];
  const highlightPaths: Array<{ type: 'stroke' | 'wash' | 'stipple'; color: string; lineWidth: number; d: string }> = [];

  // 1. Hills & ground line
  sketchPaths.push({
    type: 'stroke',
    color: '#2B2625',
    lineWidth: 1.8,
    d: `M 40 ${houseY + houseH + 20} Q ${width / 2} ${houseY + houseH - 10} ${width - 40} ${houseY + houseH + 20}`
  });

  // House contour
  sketchPaths.push({
    type: 'stroke',
    color: '#2B2625',
    lineWidth: 2.2,
    d: `M ${houseX} ${houseY + houseH} V ${houseY} H ${houseX + houseW} V ${houseY + houseH} Z`
  });

  // Roof
  sketchPaths.push({
    type: 'stroke',
    color: '#2B2625',
    lineWidth: 2.4,
    d: `M ${houseX - 15} ${houseY} L ${houseX + houseW / 2} ${houseY - roofHeight} L ${houseX + houseW + 15} ${houseY} Z`
  });

  // Chimney
  const chimneyX = houseX + houseW * 0.7;
  sketchPaths.push({
    type: 'stroke',
    color: '#2B2625',
    lineWidth: 1.8,
    d: `M ${chimneyX} ${houseY - 20} V ${houseY - roofHeight - 15} H ${chimneyX + 25} V ${houseY - 10}`
  });

  // Windows & Door
  const doorX = houseX + houseW * 0.4;
  sketchPaths.push({
    type: 'stroke',
    color: '#2B2625',
    lineWidth: 1.8,
    d: `M ${doorX} ${houseY + houseH} V ${houseY + houseH * 0.4} H ${doorX + 35} V ${houseY + houseH} Z`
  });

  const winX = houseX + houseW * 0.15;
  sketchPaths.push({
    type: 'stroke',
    color: '#2B2625',
    lineWidth: 1.5,
    d: `M ${winX} ${houseY + 30} H ${winX + 35} V ${houseY + 70} H ${winX} Z M ${winX + 17} ${houseY + 30} V ${houseY + 70} M ${winX} ${houseY + 50} H ${winX + 35}`
  });

  // Trees
  for (let i = 0; i < treeCount; i++) {
    const tx = 90 + (i * (width - 180)) / (treeCount - 1) + (rng() * 40 - 20);
    const ty = houseY + houseH;
    const th = 180 + rng() * 120;

    // Trunk
    sketchPaths.push({
      type: 'stroke',
      color: '#302621',
      lineWidth: 2.0,
      d: `M ${tx} ${ty} Q ${tx + (rng() * 30 - 15)} ${ty - th * 0.5} ${tx + (rng() * 20 - 10)} ${ty - th}`
    });

    // Foliage crown
    sketchPaths.push({
      type: 'stroke',
      color: '#343B2A',
      lineWidth: 1.4,
      d: `M ${tx - 40} ${ty - th + 30} C ${tx - 70} ${ty - th - 30} ${tx} ${ty - th - 60} ${tx + 50} ${ty - th - 20} C ${tx + 80} ${ty - th + 30} ${tx + 30} ${ty - th + 70} ${tx - 40} ${ty - th + 30} Z`
    });

    // Watercolor foliage wash
    washPaths.push({
      type: 'wash',
      color: 'rgba(140, 185, 90, 0.55)',
      lineWidth: 35,
      d: `M ${tx - 30} ${ty - th} Q ${tx} ${ty - th - 40} ${tx + 30} ${ty - th} T ${tx - 30} ${ty - th}`
    });

    // Texture dapples
    texturePaths.push({
      type: 'wash',
      color: 'rgba(60, 110, 65, 0.7)',
      lineWidth: 18,
      d: `M ${tx - 20} ${ty - th + 10} Q ${tx + 10} ${ty - th - 10} ${tx + 20} ${ty - th + 20}`
    });
  }

  // Base washes
  washPaths.push(
    { type: 'wash', color: skyColor, lineWidth: 40, d: `M 30 180 Q ${width / 2} 120 ${width - 30} 180 L ${width - 30} 340 L 30 340 Z` },
    { type: 'wash', color: 'rgba(215, 225, 160, 0.5)', lineWidth: 45, d: `M 30 ${houseY + houseH} Q ${width / 2} ${houseY + houseH - 20} ${width - 30} ${houseY + houseH} L ${width - 30} 780 L 30 780 Z` },
    { type: 'wash', color: roofColor, lineWidth: 24, d: `M ${houseX - 10} ${houseY} L ${houseX + houseW / 2} ${houseY - roofHeight + 5} L ${houseX + houseW + 10} ${houseY} Z` },
    { type: 'wash', color: 'rgba(235, 230, 215, 0.8)', lineWidth: 30, d: `M ${houseX + 5} ${houseY + 5} H ${houseX + houseW - 5} V ${houseY + houseH - 5} H ${houseX + 5} Z` }
  );

  // Cloud highlights
  highlightPaths.push({
    type: 'wash',
    color: 'rgba(255, 255, 255, 0.85)',
    lineWidth: 25,
    d: `M 140 180 C 160 130 240 130 270 170 C 310 150 360 170 360 210`
  });

  return {
    id,
    title: `어반스케치 숲과 전원마을 #${Math.floor(rng() * 900 + 100)}`,
    category: 'urban',
    categoryName: '어반스케치 & 수채화',
    difficulty,
    difficultyName: difficulty === 'easy' ? '초급 (편안한 힐링)' : difficulty === 'medium' ? '중급 (몰입 힐링)' : '고급 (디테일 마스터)',
    volume: '알고리즘 생성',
    description: '수학적 알고리즘으로 매번 다르게 생성되는 고유한 어반스케치 풍경입니다. 사각거리는 펜선과 맑은 수채화 터치를 온전히 누려보세요.',
    durationSeconds: difficulty === 'easy' ? 25 : difficulty === 'medium' ? 38 : 50,
    width,
    height,
    palette: [roofColor, '#5B85AA', '#8CB369', '#4A7C59', '#F4F1DE', '#D4E09B', '#2B2625'],
    layers: [
      { id: 'l1', name: '01. 펜 스케치 윤곽선', style: 'pen', paths: sketchPaths },
      { id: 'l2', name: '02. 맑은 수채화 초벌 번짐', style: 'watercolor', paths: washPaths },
      { id: 'l3', name: '03. 잎사귀 명암 & 지붕 텍스처', style: 'watercolor', paths: texturePaths },
      { id: 'l4', name: '04. 구름 & 햇살 하이라이트', style: 'highlight', paths: highlightPaths }
    ]
  };
}

function generateProceduralBotanical(rng: () => number, difficulty: ArtDifficulty): Artwork {
  const width = 680;
  const height = 750;
  const id = `procedural-botanical-${Date.now()}-${Math.floor(rng() * 1000)}`;
  const petalCount = difficulty === 'easy' ? 6 : difficulty === 'medium' ? 8 : 12;
  const cx = width / 2;
  const cy = height / 2 - 20;

  const sketchPaths: Array<{ type: 'stroke'; color: string; lineWidth: number; d: string }> = [];
  const washPaths: Array<{ type: 'wash'; color: string; lineWidth: number; d: string }> = [];
  const highlightPaths: Array<{ type: 'stipple' | 'stroke'; color: string; lineWidth: number; d: string }> = [];

  const mainColor = ['#E29578', '#DDA15E', '#9B5DE5', '#F15BB5', '#4EA8DE'][Math.floor(rng() * 5)];
  const leafColor = '#52796F';

  // Stem
  sketchPaths.push({
    type: 'stroke',
    color: '#283618',
    lineWidth: 2.2,
    d: `M ${cx} ${cy + 60} Q ${cx - 20} ${cy + 220} ${cx - 10} ${height - 60}`
  });

  // Blooming petals
  for (let i = 0; i < petalCount; i++) {
    const angle = (i * 2 * Math.PI) / petalCount;
    const r1 = 120 + rng() * 30;
    const px = cx + Math.cos(angle) * r1;
    const py = cy + Math.sin(angle) * r1;

    const cAngle1 = angle - 0.25;
    const cAngle2 = angle + 0.25;
    const cr = r1 * 0.6;
    const cx1 = cx + Math.cos(cAngle1) * cr;
    const cy1 = cy + Math.sin(cAngle1) * cr;
    const cx2 = cx + Math.cos(cAngle2) * cr;
    const cy2 = cy + Math.sin(cAngle2) * cr;

    sketchPaths.push({
      type: 'stroke',
      color: '#283618',
      lineWidth: 1.6,
      d: `M ${cx} ${cy} C ${cx1} ${cy1} ${px} ${py} ${px} ${py} C ${px} ${py} ${cx2} ${cy2} ${cx} ${cy} Z`
    });

    washPaths.push({
      type: 'wash',
      color: mainColor,
      lineWidth: 22,
      d: `M ${cx} ${cy} Q ${(cx + px) / 2} ${(cy + py) / 2} ${px} ${py}`
    });
  }

  // Leaves along stem
  sketchPaths.push(
    { type: 'stroke', color: '#283618', lineWidth: 1.8, d: `M ${cx - 15} ${cy + 160} Q ${cx - 90} ${cy + 120} ${cx - 130} ${cy + 170} Q ${cx - 70} ${cy + 200} ${cx - 12} ${cy + 190} Z` },
    { type: 'stroke', color: '#283618', lineWidth: 1.8, d: `M ${cx - 10} ${cy + 240} Q ${cx + 70} ${cy + 200} ${cx + 120} ${cy + 250} Q ${cx + 60} ${cy + 280} ${cx - 5} ${cy + 270} Z` }
  );

  washPaths.push(
    { type: 'wash', color: leafColor, lineWidth: 25, d: `M ${cx - 15} ${cy + 170} Q ${cx - 90} ${cy + 150} ${cx - 120} ${cy + 170}` },
    { type: 'wash', color: leafColor, lineWidth: 25, d: `M ${cx - 5} ${cy + 250} Q ${cx + 70} ${cy + 230} ${cx + 110} ${cy + 250}` }
  );

  // Pollen center
  highlightPaths.push(
    { type: 'stipple', color: '#FFB703', lineWidth: 8, d: `M ${cx} ${cy} M ${cx - 10} ${cy + 5} M ${cx + 8} ${cy - 6}` }
  );

  return {
    id,
    title: `보태니컬 만다라 플라워 #${Math.floor(rng() * 900 + 100)}`,
    category: 'botanical',
    categoryName: '보태니컬 & 네이처',
    difficulty,
    difficultyName: difficulty === 'easy' ? '초급 (편안한 힐링)' : difficulty === 'medium' ? '중급 (몰입 힐링)' : '고급 (디테일 마스터)',
    volume: '알고리즘 생성',
    description: '기하학적 대칭과 싱그러운 잎맥이 어우러진 보태니컬 플로라 도안입니다.',
    durationSeconds: difficulty === 'easy' ? 22 : 35,
    width,
    height,
    palette: [mainColor, leafColor, '#283618', '#FFB703', '#F4F1DE'],
    layers: [
      { id: 'l1', name: '01. 보태니컬 펜 스케치', style: 'pen', paths: sketchPaths },
      { id: 'l2', name: '02. 수채화 꽃잎 & 잎사귀 번짐', style: 'watercolor', paths: washPaths },
      { id: 'l3', name: '03. 꽃술 & 이슬방울 하이라이트', style: 'highlight', paths: highlightPaths }
    ]
  };
}

function generateProceduralOil(rng: () => number, difficulty: ArtDifficulty): Artwork {
  const width = 720;
  const height = 560;
  const id = `procedural-oil-${Date.now()}-${Math.floor(rng() * 1000)}`;

  const paths1: Array<{ type: 'wash' | 'stroke'; color: string; lineWidth: number; d: string }> = [];
  const paths2: Array<{ type: 'stroke'; color: string; lineWidth: number; d: string }> = [];

  paths1.push({ type: 'wash', color: '#0F2537', lineWidth: 60, d: `M 0 0 H ${width} V ${height} H 0 Z` });

  // Horizon & waves
  for (let i = 0; i < 5; i++) {
    const y = 200 + i * 65;
    paths1.push({
      type: 'stroke',
      color: i % 2 === 0 ? '#1E4E79' : '#306998',
      lineWidth: 12 - i,
      d: `M 0 ${y} Q ${width * 0.3} ${y - 20} ${width * 0.6} ${y + 15} T ${width} ${y}`
    });
  }

  // Impasto swirls
  for (let j = 0; j < (difficulty === 'easy' ? 4 : 8); j++) {
    const sx = 80 + rng() * (width - 160);
    const sy = 60 + rng() * 180;
    paths2.push({
      type: 'stroke',
      color: '#E8A838',
      lineWidth: 7.0,
      d: `M ${sx} ${sy} C ${sx + 30} ${sy - 20} ${sx + 60} ${sy + 20} ${sx + 40} ${sy + 40} C ${sx + 10} ${sy + 50} ${sx - 10} ${sy + 10} ${sx + 20} ${sy}`
    });
  }

  return {
    id,
    title: `인상주의 유화의 바다 & 노을 #${Math.floor(rng() * 900 + 100)}`,
    category: 'oil',
    categoryName: '클래식 유화 (임파스토)',
    difficulty,
    difficultyName: difficulty === 'easy' ? '초급 (편안한 힐링)' : '중급 (몰입 힐링)',
    volume: '알고리즘 생성',
    description: '물결치는 붓결과 두터운 임파스토 텍스처로 완성하는 유화 작품입니다.',
    durationSeconds: 34,
    width,
    height,
    palette: ['#0F2537', '#1E4E79', '#306998', '#E8A838', '#F9E4B7', '#D9534F'],
    layers: [
      { id: 'l1', name: '01. 심해 & 밤하늘 붓터치', style: 'oil', paths: paths1 },
      { id: 'l2', name: '02. 황금빛 임파스토 빛소용돌이', style: 'highlight', paths: paths2 }
    ]
  };
}

function generateProceduralPop(rng: () => number, difficulty: ArtDifficulty): Artwork {
  const width = 640;
  const height = 640;
  const id = `procedural-pop-${Date.now()}-${Math.floor(rng() * 1000)}`;

  const lines: Array<{ type: 'stroke'; color: string; lineWidth: number; d: string }> = [];
  const fills: Array<{ type: 'wash'; color: string; lineWidth: number; d: string }> = [];

  // Sun
  lines.push({ type: 'stroke', color: '#1B1B1B', lineWidth: 4.0, d: 'M 320 200 A 100 100 0 1 1 320 201' });
  fills.push({ type: 'wash', color: '#FFB703', lineWidth: 50, d: 'M 320 200 A 70 70 0 1 1 320 201' });

  // Geometric landscape
  lines.push(
    { type: 'stroke', color: '#1B1B1B', lineWidth: 4.0, d: 'M 40 450 L 220 280 L 400 450 Z' },
    { type: 'stroke', color: '#1B1B1B', lineWidth: 4.0, d: 'M 280 450 L 440 310 L 600 450 Z' },
    { type: 'stroke', color: '#1B1B1B', lineWidth: 4.0, d: 'M 40 450 H 600 V 580 H 40 Z' }
  );

  fills.push(
    { type: 'wash', color: '#E63946', lineWidth: 35, d: 'M 50 445 L 220 290 L 390 445 Z' },
    { type: 'wash', color: '#457B9D', lineWidth: 35, d: 'M 290 445 L 440 320 L 590 445 Z' },
    { type: 'wash', color: '#1D3557', lineWidth: 40, d: 'M 40 460 H 600 V 570 H 40 Z' }
  );

  return {
    id,
    title: `팝아트 선셋 지오메트리 #${Math.floor(rng() * 900 + 100)}`,
    category: 'pop',
    categoryName: '팝아트 & 모던 그래픽',
    difficulty,
    difficultyName: '초급 (편안한 힐링)',
    volume: '알고리즘 생성',
    description: '비비드한 색채와 기하학적 형태가 만들어내는 현대적 팝아트 일러스트입니다.',
    durationSeconds: 20,
    width,
    height,
    palette: ['#E63946', '#FFB703', '#457B9D', '#1D3557', '#1B1B1B'],
    layers: [
      { id: 'l1', name: '01. 볼드 블랙 라인워크', style: 'pen', paths: lines },
      { id: 'l2', name: '02. 비비드 팝 컬러 블록', style: 'watercolor', paths: fills }
    ]
  };
}
