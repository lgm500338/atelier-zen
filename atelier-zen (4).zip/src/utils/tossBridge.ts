import { saveBase64Data, SafeAreaInsets } from '@apps-in-toss/web-framework';

/**
 * Safe Area Insets 초기화 및 실시간 구독
 * Toss 앱인토스 네이티브 브릿지에서 Inset 값을 가져와 CSS 변수(--sat, --sab, --sal, --sar)에 주입합니다.
 * Toss 환경이 아니거나 에러 발생 시 CSS :root에 정의된 env(safe-area-inset-*)로 안전하게 폴백됩니다.
 */
export function initSafeArea(): () => void {
  if (typeof window === 'undefined' || typeof document === 'undefined') {
    return () => {};
  }

  const applyInsets = (insets?: { top?: number; bottom?: number; left?: number; right?: number }) => {
    if (!insets) return;
    const root = document.documentElement;
    if (typeof insets.top === 'number') {
      root.style.setProperty('--sat', `${insets.top}px`);
    }
    if (typeof insets.bottom === 'number') {
      root.style.setProperty('--sab', `${insets.bottom}px`);
    }
    if (typeof insets.left === 'number') {
      root.style.setProperty('--sal', `${insets.left}px`);
    }
    if (typeof insets.right === 'number') {
      root.style.setProperty('--sar', `${insets.right}px`);
    }
  };

  try {
    // 1. 현재 Safe Area 값 즉시 조회 및 적용
    const currentInsets = SafeAreaInsets.get();
    applyInsets(currentInsets);

    // 2. 화면 회전이나 인셋 변화 이벤트 구독
    const unsubscribe = SafeAreaInsets.subscribe({
      onEvent: (newInsets) => {
        applyInsets(newInsets);
      },
    });

    return typeof unsubscribe === 'function' ? unsubscribe : () => {};
  } catch {
    // 브라우저 또는 미지원 환경: CSS env() 폴백 유지
    return () => {};
  }
}

/**
 * 작품 이미지 저장 함수
 * 1. 앱인토스 SDK saveBase64Data({ data, fileName, mimeType }) 시도
 *    (토스 SDK 규격에 맞춰 'data:image/...;base64,' 접두사를 제거한 순수 base64 전달)
 * 2. 실패 시 웹 표준 <a download> 폴백
 */
export async function saveArtworkImage(
  dataUrl: string,
  fileName: string = 'atelier-zen-artwork.png'
): Promise<boolean> {
  // data:image/png;base64,... 에서 mimeType과 순수 base64 데이터 분리
  const match = dataUrl.match(/^data:([^;]+);base64,(.+)$/);
  const mimeType = match ? match[1] : 'image/png';
  const rawBase64 = match ? match[2] : dataUrl;

  // 1. 토스 SDK 네이티브 파일 저장 시도
  try {
    await saveBase64Data({
      data: rawBase64,
      fileName,
      mimeType,
    });
    return true;
  } catch {
    // 앱인토스 환경이 아니거나 SDK 호출 실패 시 웹 브라우저 폴백으로 이동
  }

  // 2. 일반 웹 브라우저 다운로드 폴백
  try {
    const link = document.createElement('a');
    link.download = fileName;
    link.href = dataUrl;
    link.target = '_blank';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    return true;
  } catch (webErr) {
    console.warn('Fallback download failed:', webErr);
    return false;
  }
}
