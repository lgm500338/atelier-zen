import { Artwork, DrawingLayer, DrawPath } from '../types/artwork';

// 100% Client-Side Pure Computer Vision: Photo to Sketch Converter
// Zero external API calls, runs entirely in the user's browser canvas.

export interface PhotoSketchOptions {
  detailLevel: 'fine' | 'medium' | 'bold'; // Line weight
  contrast: number; // 0.8 ~ 2.0
  threshold: number; // 20 ~ 120 edge sensitivity
  colorWash: boolean; // whether to generate soft watercolor base from original photo
}

export async function convertPhotoToArtwork(
  file: File,
  options: PhotoSketchOptions = { detailLevel: 'medium', contrast: 1.2, threshold: 45, colorWash: true }
): Promise<Artwork> {
  const originalImageUrl = await readFileAsDataURL(file);
  const img = await loadImage(originalImageUrl);

  // Target resolution for crisp drawing
  const maxDim = 800;
  let targetW = img.width;
  let targetH = img.height;

  if (targetW > maxDim || targetH > maxDim) {
    if (targetW > targetH) {
      targetH = Math.round((targetH * maxDim) / targetW);
      targetW = maxDim;
    } else {
      targetW = Math.round((targetW * maxDim) / targetH);
      targetH = maxDim;
    }
  }

  // Offscreen canvas for pixel analysis
  const canvas = document.createElement('canvas');
  canvas.width = targetW;
  canvas.height = targetH;
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  if (!ctx) throw new Error('Canvas context unavailable');

  ctx.drawImage(img, 0, 0, targetW, targetH);
  const imgData = ctx.getImageData(0, 0, targetW, targetH);
  const pixels = imgData.data;

  // Extract representative 6-color palette from original photo
  const palette = extractPalette(pixels);

  // 1. Grayscale & Contrast enhancement
  const gray = new Float32Array(targetW * targetH);
  for (let i = 0; i < pixels.length; i += 4) {
    const r = pixels[i];
    const g = pixels[i + 1];
    const b = pixels[i + 2];
    // Luminance
    let luma = 0.299 * r + 0.587 * g + 0.114 * b;
    // Apply contrast curve
    luma = ((luma / 255 - 0.5) * options.contrast + 0.5) * 255;
    gray[i / 4] = Math.max(0, Math.min(255, luma));
  }

  // 2. Sobel Edge Detection (Mathematical gradient calculation)
  const edges = new Uint8Array(targetW * targetH);
  const step = options.detailLevel === 'fine' ? 2 : options.detailLevel === 'medium' ? 3 : 4;
  const sketchPaths: DrawPath[] = [];

  for (let y = 1; y < targetH - 1; y++) {
    for (let x = 1; x < targetW - 1; x++) {
      const idx = y * targetW + x;

      // Sobel kernels
      const gx =
        -gray[idx - targetW - 1] + gray[idx - targetW + 1] +
        -2 * gray[idx - 1] + 2 * gray[idx + 1] +
        -gray[idx + targetW - 1] + gray[idx + targetW + 1];

      const gy =
        -gray[idx - targetW - 1] - 2 * gray[idx - targetW] - gray[idx - targetW + 1] +
        gray[idx + targetW - 1] + 2 * gray[idx + targetW] + gray[idx + targetW + 1];

      const mag = Math.sqrt(gx * gx + gy * gy);
      if (mag > options.threshold) {
        edges[idx] = 255;
      }
    }
  }

  // 3. Trace strokes from edges into SVG path batches for realistic pen timelapse
  for (let y = 4; y < targetH - 4; y += step * 2) {
    let currentStroke: Array<[number, number]> = [];
    for (let x = 4; x < targetW - 4; x += step) {
      const idx = y * targetW + x;
      if (edges[idx] === 255) {
        currentStroke.push([x, y]);
      } else {
        if (currentStroke.length >= 3) {
          sketchPaths.push(pointsToPath(currentStroke, options.detailLevel));
        }
        currentStroke = [];
      }
    }
    if (currentStroke.length >= 3) {
      sketchPaths.push(pointsToPath(currentStroke, options.detailLevel));
    }
  }

  // Vertical pass for cross-hatching look
  for (let x = 4; x < targetW - 4; x += step * 3) {
    let currentStroke: Array<[number, number]> = [];
    for (let y = 4; y < targetH - 4; y += step) {
      const idx = y * targetW + x;
      if (edges[idx] === 255) {
        currentStroke.push([x, y]);
      } else {
        if (currentStroke.length >= 4) {
          sketchPaths.push(pointsToPath(currentStroke, options.detailLevel));
        }
        currentStroke = [];
      }
    }
  }

  // Fallback: If image was too soft/blurry, add contour framing
  if (sketchPaths.length < 10) {
    sketchPaths.push({
      type: 'stroke',
      color: '#2B2625',
      lineWidth: 2,
      d: `M 20 20 H ${targetW - 20} V ${targetH - 20} H 20 Z`
    });
  }

  const layers: DrawingLayer[] = [
    {
      id: 'photo-pen-sketch',
      name: '01. 로컬 변환 펜 스케치 윤곽선',
      style: 'pen',
      paths: sketchPaths
    }
  ];

  // Optional soft watercolor wash layer from downscaled colors
  if (options.colorWash) {
    const washPaths: DrawPath[] = [];
    const gridSize = 60;
    for (let gy = 0; gy < targetH; gy += gridSize) {
      for (let gx = 0; gx < targetW; gx += gridSize) {
        const px = Math.min(targetW - 1, gx + gridSize / 2);
        const py = Math.min(targetH - 1, gy + gridSize / 2);
        const pIdx = (py * targetW + px) * 4;
        const r = pixels[pIdx];
        const g = pixels[pIdx + 1];
        const b = pixels[pIdx + 2];

        washPaths.push({
          type: 'wash',
          color: `rgba(${r}, ${g}, ${b}, 0.45)`,
          lineWidth: gridSize * 0.9,
          d: `M ${gx} ${gy} Q ${gx + gridSize / 2} ${gy - 5} ${gx + gridSize} ${gy} T ${gx + gridSize} ${gy + gridSize} T ${gx} ${gy + gridSize} Z`
        });
      }
    }

    layers.push({
      id: 'photo-base-wash',
      name: '02. 사진 본연의 맑은 수채화 언더톤',
      style: 'watercolor',
      paths: washPaths
    });
  }

  const cleanTitle = file.name.replace(/\.[^/.]+$/, '').slice(0, 18);

  return {
    id: `custom-sketch-${Date.now()}`,
    title: `${cleanTitle} (내 사진 스케치)`,
    category: 'user',
    categoryName: '내 사진 스케치북',
    difficulty: 'medium',
    difficultyName: '중급 (자유 채색)',
    volume: '개인 앨범',
    description: '내 사진을 브라우저 로컬 컴퓨터 그래픽스 알고리즘으로 즉시 변환한 스케치 도안입니다. (100% 무료, API 없음)',
    durationSeconds: Math.min(60, Math.max(20, Math.floor(sketchPaths.length * 0.12))),
    width: targetW,
    height: targetH,
    palette,
    layers,
    isCustom: true,
    sourceImage: canvas.toDataURL('image/jpeg', 0.8),
    createdAt: new Date().toLocaleDateString('ko-KR')
  };
}

function pointsToPath(points: Array<[number, number]>, detail: string): DrawPath {
  const [first, ...rest] = points;
  let d = `M ${first[0]} ${first[1]}`;
  for (let i = 0; i < rest.length; i++) {
    d += ` L ${rest[i][0]} ${rest[i][1]}`;
  }
  return {
    type: 'stroke',
    color: '#262220',
    lineWidth: detail === 'fine' ? 1.2 : detail === 'medium' ? 1.8 : 2.6,
    d
  };
}

function extractPalette(pixels: Uint8ClampedArray): string[] {
  // Simple k-means-like or sample-based dominant color palette
  const sampledColors: Array<[number, number, number]> = [];
  const step = Math.floor(pixels.length / (4 * 100)); // 100 sample pixels
  for (let i = 0; i < pixels.length; i += step * 4) {
    sampledColors.push([pixels[i], pixels[i + 1], pixels[i + 2]]);
  }

  // Pick 6 distinct colors
  const palette: string[] = [];
  const toHex = (c: number) => c.toString(16).padStart(2, '0');

  for (let i = 0; i < sampledColors.length && palette.length < 8; i += 12) {
    const [r, g, b] = sampledColors[i];
    const hex = `#${toHex(r)}${toHex(g)}${toHex(b)}`;
    if (!palette.includes(hex)) {
      palette.push(hex);
    }
  }

  // Ensure default comforting fallback swatches
  if (palette.length < 6) {
    palette.push('#4A7C59', '#D4E09B', '#C94A29', '#5B85AA', '#E09F3E', '#2B2625');
  }

  return palette.slice(0, 8);
}

function readFileAsDataURL(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function loadImage(url: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = url;
  });
}
